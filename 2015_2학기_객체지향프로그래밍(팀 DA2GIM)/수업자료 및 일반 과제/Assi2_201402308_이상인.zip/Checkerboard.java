public class Checkerboard{
  public static void main(String[] args){
    int N = Integer.parseInt(args[0]);
    for(int i = 1 ; i<=N ; i++){
      if(i%2 != 0){
        int a=1;
        for(;a<=N;a++){
        System.out.print("* ");
        }
        System.out.println();
      }
      if(i%2 == 0){
        int a=1;
        for(;a<=N;a++){
        System.out.print(" *");
        }
        System.out.println();
      }
    }
  }
}