public class PrimeCounter{
  public static void main(String[] args){
    //���� �� �ʱ�ȭ
    int N = Integer.parseInt(args[0]);
    int howManyInLine = 15;
    int countLine = 0; 
    int num = 2; 
    
    while (num <= N) {
      //���������
      boolean nowPrime = true;
      //���������� Ȯ��
      for (int checkPrime = 2; checkPrime <= (int)Math.sqrt(num);checkPrime++) {
        if (num % checkPrime == 0) { 
          nowPrime = false;       
        }
      }
      //15���� ���
      if (nowPrime==true) {
        countLine++;
        if (countLine % howManyInLine != 0) {
          System.out.print(num+" ");
        }
        else
          System.out.println(num);
      }
      num++;
    }
  }
}