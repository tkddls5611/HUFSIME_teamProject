public class FourRoot { 
  public static void main(String[] args) { 
    double epsilon = 1e-5;
    double c = Double.parseDouble(args[0]);
    double t = c;
    
    while (Math.abs(t - c/t) > t*epsilon) {
      t = (c/(Math.pow(t,3)) + 3*t) / 4.0; 
      System.out.println(t); 
    } 
    System.out.println(t); 
  } 
}