public class population {
  public static void main(String[] args) { 
    double xmin = StdIn.readDouble(); 
    double ymin = StdIn.readDouble();  
    double xmax = StdIn.readDouble();   
    double ymax = StdIn.readDouble(); 
    StdDraw.setXscale(xmin, xmax);       
    StdDraw.setYscale(ymin, ymax); 
    
    while (!StdIn.isEmpty()) { 
      double r = StdIn.readDouble(); 
      double x = StdIn.readDouble(); 
      double y = StdIn.readDouble(); 
      StdDraw.point(x,y);
      if(r<10000000){
      StdDraw.circle(x,y,r/5500000);
      }else{StdDraw.circle(x,y,r/7000000);}
      
    } 
  } 
}