public class S8_UnoPlayer implements UnoPlayer {

    public int play(Card[] hand, Card upCard, Color calledColor, GameState state) {
      
 
      
      //1
        if(state.getNumCardsInHandsOfUpcomingPlayers()[0] <= 3 && state.getNumCardsInHandsOfUpcomingPlayers()[1] > 3){
            for(int i = 0; i < hand.length; i++){
                if((hand[i].getRank() == Rank.DRAW_TWO) && (hand[i].getColor() == upCard.getColor())
                      || (hand[i].getRank() == Rank.SKIP) && (hand[i].getColor() == upCard.getColor())){
                    return i;
                }
            }
        }else if(state.getNumCardsInHandsOfUpcomingPlayers()[0] <= 3 && state.getNumCardsInHandsOfUpcomingPlayers()[1] <= 3){ //2
            for(int i = 0; i < hand.length; i++){
                if(((hand[i].getRank() == Rank.REVERSE) && (hand[i].getColor() == upCard.getColor()))
                     || hand[i].getRank() == Rank.WILD || hand[i].getRank() == Rank.WILD_D4){
                    return i;
                }
            }
        }
        //3
      int totalplayed =state.getPlayedCards().length;
        if(totalplayed > 30){
            int me_total =0;
            for(int i=0;i<hand.length;i++){
                if(hand[i].getNumber() ==0 || hand[i].getNumber() ==1 || hand[i].getNumber() ==2 || hand[i].getNumber() ==3 || hand[i].getNumber() ==4 || hand[i].getNumber() ==5 
                     || hand[i].getNumber() ==6 || hand[i].getNumber() ==7 || hand[i].getNumber() ==8 || hand[i].getNumber() ==9){
                    me_total +=hand[i].getNumber();
                }else if(hand[i].getRank() == Rank.SKIP || hand[i].getRank() == Rank.DRAW_TWO || hand[i].getRank() == Rank.REVERSE){
                    me_total += 20;
                }else me_total +=50;
            }
            int zerototal = state.getTotalScoreOfUpcomingPlayers()[1] + state.getTotalScoreOfUpcomingPlayers()[2] + me_total;
            int firtotal = state.getTotalScoreOfUpcomingPlayers()[0] + state.getTotalScoreOfUpcomingPlayers()[2] + me_total;
            int sectotal = state.getTotalScoreOfUpcomingPlayers()[0] + state.getTotalScoreOfUpcomingPlayers()[1] + me_total;
            if((zerototal >100 || firtotal >100 || sectotal > 100) && hand.length<4){
                for(int i = 0; i < hand.length; i++){
                    if(hand[i].getRank() == Rank.WILD || hand[i].getRank() == Rank.WILD_D4 ){
                        return i;
                    }else   if((hand[i].getRank() == Rank.REVERSE) && (hand[i].getColor() == upCard.getColor())
                                  || ((hand[i].getRank() == Rank.SKIP) && (hand[i].getColor() == upCard.getColor()))
                                  || ((hand[i].getRank() == Rank.DRAW_TWO) && (hand[i].getColor()) == upCard.getColor())) {
                        return i;
                    }
                }
            }
        }

        int max=0;
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getColor()== upCard.getColor()) || (hand[i].getNumber() == upCard.getNumber())){
                if(max<hand[i].getNumber()){  
                    max = hand[i].getNumber();
                }
            }
        }
        for(int i=0;i<hand.length;i++){
            if((hand[i].getColor()== upCard.getColor()) || (hand[i].getNumber() == upCard.getNumber())&&(hand[i].getNumber() == max)){
                return i;
            }
        }

        for(int i = 0; i < hand.length; i++){
            if(((hand[i].getColor()== upCard.getColor()) || (hand[i].getRank() == upCard.getRank()))){
                if((hand[i].getNumber() == upCard.getNumber())&& (hand[i].getRank() == upCard.getRank())){
                  return i;
                }
            }
        }  
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getRank() == Rank.WILD_D4)){
              return i;
            }
        }
        for(int i = 0; i < hand.length; i++){
            if(hand[i].getRank() == Rank.WILD){
                return i;
            }
        }  
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getColor()== upCard.getColor())&& (hand[i].getRank() == Rank.DRAW_TWO)){
                return i;
            }
        }   
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getColor()== upCard.getColor()) && hand[i].getRank() == Rank.SKIP){
                return i;
            }
        }  
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getColor()== upCard.getColor()) && hand[i].getRank() == Rank.REVERSE){
                return i;
            }
        }
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getRank() == upCard.getRank()) && (hand[i].getNumber() == upCard.getNumber())){
                return i;
            }else if((hand[i].getRank() == upCard.getRank())&&(hand[i].getColor() == upCard.getColor())){
              return i;
            }  
        }
        for(int i = 0; i < hand.length; i++){ 
            if(hand[i].getColor() == upCard.getColor() || hand[i].getColor() == calledColor){ 
                return i; 
            }else if(hand[i].getRank() == Rank.NUMBER){
                if(hand[i].getNumber() == upCard.getNumber()){
                    return i;
                }
            }else if(hand[i].getRank() == upCard.getRank()){
                if(upCard.getRank() == Rank.DRAW_TWO || upCard.getRank() == Rank.REVERSE || upCard.getRank() == Rank.SKIP
                     || upCard.getRank() == Rank.WILD || upCard.getRank() == Rank.WILD_D4){
                    return i;
                }
            }
        }
        return -1;
 }
    public Color callColor(Card[] hand) {

        int ycount =0;
        int bcount =0;
        int gcount =0;
        int rcount =0; 
        for(int i=0;i<hand.length;i++){
            if(hand[i].getColor() == Color.YELLOW){
                ycount++;
            }else if(hand[i].getColor() == Color.BLUE){
                bcount++;
            }else if(hand[i].getColor() == Color.GREEN){
                gcount++;
            }else if(hand[i].getColor() == Color.RED){
                rcount++;
            }
        }
        int max =0;
        max = Math.max(rcount,Math.max(gcount,Math.max(ycount,bcount)));
        if(max ==ycount){
            return Color.YELLOW;
        }else if(max ==bcount){
            return Color.BLUE;
        }else if(max ==gcount){
            return Color.GREEN;
        }else{
            return Color.RED;
        }
    }
}