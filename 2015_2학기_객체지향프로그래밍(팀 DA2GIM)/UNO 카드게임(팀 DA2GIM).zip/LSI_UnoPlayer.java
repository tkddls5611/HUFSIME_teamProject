public class LSI_UnoPlayer implements UnoPlayer {

    public int play(Card[] hand, Card upCard, Color calledColor,GameState state){
      //������� ī�尹���� 3�����ϰ� �� �����縲��   ī�尹���� 3�庸�� ������ draw2 �� skip
        if(state.getNumCardsInHandsOfUpcomingPlayers()[0] <= 3 && state.getNumCardsInHandsOfUpcomingPlayers()[1] > 3){
            for(int i = 0; i < hand.length; i++){
                if((hand[i].getRank() == Rank.DRAW_TWO) && (hand[i].getColor() == upCard.getColor()
                                                              || (hand[i].getRank() == Rank.SKIP) && (hand[i].getColor() == upCard.getColor()))){
                    return i;
                }
            }//��������� �� ������� ī�尹���� �Ѵ� 3�� �����̸� reverse �� wild �� wild4
        }else if(state.getNumCardsInHandsOfUpcomingPlayers()[0] <= 3 && state.getNumCardsInHandsOfUpcomingPlayers()[1] <= 3){

          for(int i = 0; i < hand.length; i++){
                if((hand[i].getRank() == Rank.REVERSE) && (hand[i].getColor() == upCard.getColor()
                                                             || (hand[i].getRank() == Rank.WILD) && (hand[i].getColor() == upCard.getColor())
                                                             || (hand[i].getRank() == Rank.WILD_D4) && (hand[i].getColor()) == upCard.getColor())){
                  return i;
                }
            }
        }
                 
          if(state.getTotalScoreOfUpcomingPlayers()[0] < 100 && state.getTotalScoreOfUpcomingPlayers()[1] < 100){
            for(int i = 0; i < hand.length; i++){
                if((hand[i].getRank() == Rank.WILD && upCard.getRank() == Rank.WILD)&&(hand[i].getColor() == upCard.getColor())
                     || (hand[i].getRank() == Rank.WILD_D4 && upCard.getRank() == Rank.WILD_D4)&&(hand[i].getColor() == upCard.getColor())){
                    return i;
                }
            }
        }else if(state.getTotalScoreOfUpcomingPlayers()[0] < 80 && state.getTotalScoreOfUpcomingPlayers()[1] < 80){
            for(int i = 0; i < hand.length; i++){
                if((hand[i].getRank() == Rank.REVERSE && upCard.getRank() == Rank.REVERSE)&&(hand[i].getColor() == upCard.getColor())
                     || (hand[i].getRank() == Rank.DRAW_TWO && upCard.getRank() == Rank.DRAW_TWO)&&(hand[i].getColor() == upCard.getColor())
                     || (hand[i].getRank() == Rank.SKIP && upCard.getRank() == Rank.SKIP)&&(hand[i].getColor() == upCard.getColor())){
                    return i;
                }
            }
        }
        if((state.getNumCardsInHandsOfUpcomingPlayers()[2] > 3 && upCard.getColor() == Color.YELLOW)
             ||(state.getNumCardsInHandsOfUpcomingPlayers()[2] > 3 && upCard.getColor() == Color.BLUE)
          ||(state.getNumCardsInHandsOfUpcomingPlayers()[2] > 3 && upCard.getColor() == Color.GREEN)
             ||(state.getNumCardsInHandsOfUpcomingPlayers()[2] > 3 && upCard.getColor() == Color.RED)){
           for(int i = 0; i < hand.length; i++){
            if(hand[i].getNumber() == upCard.getNumber()|| (hand[i].getRank() == Rank.WILD && hand[i].getColor() == upCard.getColor())){
              return i; 
            }
           }
        }
        //basic
        for(int i = 0; i < hand.length; i++) { 
            if(hand[i].getColor() == upCard.getColor() || hand[i].getColor() == calledColor){ 
                return i; 
            }else if(hand[i].getRank() == Rank.NUMBER){
                if(hand[i].getNumber() == upCard.getNumber()){
                    return i;
                }
            }else if(hand[i].getRank() == upCard.getRank()){
                if(upCard.getRank() == Rank.DRAW_TWO || upCard.getRank() == Rank.REVERSE || upCard.getRank() == Rank.SKIP
                     || upCard.getRank() == Rank.WILD || upCard.getRank() == Rank.WILD_D4){
                    return i;
                }
            }
        }
        return -1;
    }

    /**
     * callColor - This method will be called when you have just played a
     * wild card, and is your way of specifying which color you want to 
     * change it to.
     *
     * You must return a valid Color value from this method. You must not
     * return the value Color.NONE under any circumstances.
     * @param hand
     */
    public Color callColor(Card[] hand){
        int ycount =0;//1
        int bcount =0;//2
        int gcount =0;//3
        int rcount =0;//4
        
        for(int i=0;i<hand.length;i++){
            if(hand[i].getColor() == Color.YELLOW){
                ycount++;
            }else if(hand[i].getColor() == Color.BLUE){
                bcount++;
            }else if(hand[i].getColor() == Color.GREEN){
                gcount++;
            }else{
                rcount++;
            }
        }
        int max =0;
        max = Math.max(rcount,Math.max(gcount,Math.max(ycount,bcount)));
        if(max ==ycount){
            return Color.YELLOW;
        }else if(max ==bcount){
            return Color.BLUE;
        }else if(max ==gcount){
            return Color.GREEN;
        }else{
            return Color.RED;
        }
      
    }

}
