public class S2_UnoPlayer implements UnoPlayer {

 public int play(Card[] hand, Card upCard, Color calledColor, GameState state) {
   
  // 1.������� ī�尹���� 3�����ϰ� �� ��������� ī�尹���� 3�庸�� ������ draw2 �� skip
  if (state.getNumCardsInHandsOfUpcomingPlayers()[0] <= 3 && state.getNumCardsInHandsOfUpcomingPlayers()[1] > 3) {
   for (int i = 0; i < hand.length; i++) {
    if ((hand[i].getRank() == Rank.DRAW_TWO) && (hand[i].getColor() == upCard.getColor())
      || (hand[i].getRank() == Rank.SKIP) && (hand[i].getColor() == upCard.getColor())) {
     return i;
    }
   } //2. ��������� �� ������� ī�尹���� �Ѵ� 3�� �����̸� reverse �� wild �� wild4
  } else if (state.getNumCardsInHandsOfUpcomingPlayers()[0] <= 3
    && state.getNumCardsInHandsOfUpcomingPlayers()[1] <= 3) {
   for (int i = 0; i < hand.length; i++) {
    if ((hand[i].getRank() == Rank.REVERSE) && (hand[i].getColor() == upCard.getColor()
      || (hand[i].getRank() == Rank.WILD) && (hand[i].getColor() == upCard.getColor())
      || (hand[i].getRank() == Rank.WILD_D4) && (hand[i].getColor()) == upCard.getColor())) {
     return i;
    }
   }
  }
   //3.
           for(int i = 0; i < hand.length; i++){
            int ycount=0;
            int gcount=0;
            int bcount=0;
            int rcount=0;
            for(int j = 0; j < state.getPlayedCards().length; j++){
                if(state.getPlayedCards()[j].getColor() == Color.YELLOW){
                    ycount++;
                }else if(state.getPlayedCards()[j].getColor() == Color.BLUE){
                  bcount++;
                }else if(state.getPlayedCards()[j].getColor() == Color.GREEN){
                  gcount++;
                }else if(state.getPlayedCards()[j].getColor() == Color.RED){
                  rcount++;
                }
            }
                       
            if(ycount > bcount && ycount > gcount && ycount > rcount){
                if(hand[i].getColor() == Color.YELLOW){
                    return i;
                }
            }
            if(bcount > ycount && bcount > gcount && bcount > rcount){
                if(hand[i].getColor() == Color.BLUE){
                    return i;
              }
            }
            if(gcount > bcount && gcount > ycount && gcount > rcount){
                if(hand[i].getColor() == Color.GREEN){
                    return i;
                }
            }
            if(rcount > bcount && rcount > gcount && rcount > ycount){
                if(hand[i].getColor() == Color.RED){
                    return i;
                }
            } 
         }
      
 //���� �� ����
         
  for (int i = 0; i < hand.length; i++) {
    if(((hand[i].getColor()== upCard.getColor()) || (hand[i].getRank() == upCard.getRank()))){
  if ((hand[i].getNumber() == upCard.getNumber())&& (hand[i].getRank() == upCard.getRank())) {
        return i;
  }
    }
  }
  
  for (int i = 0; i < hand.length; i++) {
    if((hand[i].getRank() == Rank.WILD_D4)){
      return i;
    }
  }
  for (int i = 0; i < hand.length; i++) {
    if(hand[i].getRank() == Rank.WILD){
      return i;
    }
  }
  
  for (int i = 0; i < hand.length; i++) {
    if((hand[i].getColor()== upCard.getColor())&& (hand[i].getRank() == Rank.DRAW_TWO)){
      return i;
    }
  }
   
    for (int i = 0; i < hand.length; i++) {
    if((hand[i].getColor()== upCard.getColor()) && hand[i].getRank() == Rank.SKIP){
      return i;
    }
  }
    
    for (int i = 0; i < hand.length; i++) {
    if((hand[i].getColor()== upCard.getColor()) && hand[i].getRank() == Rank.REVERSE){
      return i;
    }
  }
  
  int max=0;//�����ִ� ī��� �� ū ���� ��
  for (int i = 0; i < hand.length; i++) {
    if ((hand[i].getColor()== upCard.getColor()) || (hand[i].getNumber() == upCard.getNumber())) {
      if(max<hand[i].getNumber()){  
      max = hand[i].getNumber();
      }
    }
  }
  for(int i=0;i<hand.length;i++){
    if(hand[i].getNumber() == max){
      return i;
    }
  }
  
  
  
 /* //�����ִ� �������
for (int i = 0; i < hand.length; i++) {
  if(hand[i].getNumber() == upCard.getNumber()){
    return i;
  }else if (hand[i].getColor() == upCard.getColor()){
    return i;
  }
    
  }*/
    //�����ִ� �������
 
  for (int i = 0; i < hand.length; i++) {
  if((hand[i].getRank() == upCard.getRank()) && (hand[i].getNumber() == upCard.getNumber())){
    return i;
  }else if ((hand[i].getRank() == upCard.getRank())&&(hand[i].getColor() == upCard.getColor())){
    return i;
  }  
  }
     for(int i = 0; i < hand.length; i++) { 
            if(hand[i].getColor() == upCard.getColor() || hand[i].getColor() == calledColor){ 
                return i; 
            }else if(hand[i].getRank() == Rank.NUMBER){
                if(hand[i].getNumber() == upCard.getNumber()){
                    return i;
                }
            }else if(hand[i].getRank() == upCard.getRank()){
                if(upCard.getRank() == Rank.DRAW_TWO || upCard.getRank() == Rank.REVERSE || upCard.getRank() == Rank.SKIP
                     || upCard.getRank() == Rank.WILD || upCard.getRank() == Rank.WILD_D4){
                    return i;
                }
            }
        }
  return -1;
 }

 public Color callColor(Card[] hand) {

  int ycount =0;//1
        int bcount =0;//2
        int gcount =0;//3
        int rcount =0;//4
        
        for(int i=0;i<hand.length;i++){
            if(hand[i].getColor() == Color.YELLOW){
                ycount++;
            }else if(hand[i].getColor() == Color.BLUE){
                bcount++;
            }else if(hand[i].getColor() == Color.GREEN){
                gcount++;
            }else{
                rcount++;
            }
        }
        int max =0;
        max = Math.max(rcount,Math.max(gcount,Math.max(ycount,bcount)));
        if(max ==ycount){
            return Color.YELLOW;
        }else if(max ==bcount){
            return Color.BLUE;
        }else if(max ==gcount){
            return Color.GREEN;
        }else{
            return Color.RED;
        }
 }

}
