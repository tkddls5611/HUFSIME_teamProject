public class S9_UnoPlayer implements UnoPlayer {

    public int play(Card[] hand, Card upCard, Color calledColor, GameState state) {
  
        if(state.getNumCardsInHandsOfUpcomingPlayers()[0] <= 3 && state.getNumCardsInHandsOfUpcomingPlayers()[1] > 3){
            for(int i = 0; i < hand.length; i++){
                if((hand[i].getRank() == Rank.DRAW_TWO) && (hand[i].getColor() == upCard.getColor())
                      || (hand[i].getRank() == Rank.SKIP) && (hand[i].getColor() == upCard.getColor())){
                    return i;
                }
            }
        }else if(state.getNumCardsInHandsOfUpcomingPlayers()[0] <= 3 && state.getNumCardsInHandsOfUpcomingPlayers()[1] <= 3){
            for(int i = 0; i < hand.length; i++){
                if(((hand[i].getRank() == Rank.REVERSE) && (hand[i].getColor() == upCard.getColor()))
                     || hand[i].getRank() == Rank.WILD || hand[i].getRank() == Rank.WILD_D4){
                    return i;
                }
            }
        }
      int totalplayed =state.getPlayedCards().length;
        if(totalplayed > 30){
            int me_total =0;
            for(int i=0;i<hand.length;i++){
                if(hand[i].getNumber() ==0 || hand[i].getNumber() ==1 || hand[i].getNumber() ==2 || hand[i].getNumber() ==3 || hand[i].getNumber() ==4 || hand[i].getNumber() ==5 
                     || hand[i].getNumber() ==6 || hand[i].getNumber() ==7 || hand[i].getNumber() ==8 || hand[i].getNumber() ==9){
                    me_total +=hand[i].getNumber();
                }else if(hand[i].getRank() == Rank.SKIP || hand[i].getRank() == Rank.DRAW_TWO || hand[i].getRank() == Rank.REVERSE){
                    me_total += 20;
                }else me_total +=50;
            }
            int zerototal = state.getTotalScoreOfUpcomingPlayers()[1] + state.getTotalScoreOfUpcomingPlayers()[2] + me_total;
            int firtotal = state.getTotalScoreOfUpcomingPlayers()[0] + state.getTotalScoreOfUpcomingPlayers()[2] + me_total;
            int sectotal = state.getTotalScoreOfUpcomingPlayers()[0] + state.getTotalScoreOfUpcomingPlayers()[1] + me_total;
            if((zerototal >100 || firtotal >100 || sectotal > 100) && hand.length<4){
                for(int i = 0; i < hand.length; i++){
                    if(hand[i].getRank() == Rank.WILD || hand[i].getRank() == Rank.WILD_D4 ){
                        return i;
                    }else   if((hand[i].getRank() == Rank.REVERSE) && (hand[i].getColor() == upCard.getColor())
                                  || ((hand[i].getRank() == Rank.SKIP) && (hand[i].getColor() == upCard.getColor()))
                                  || ((hand[i].getRank() == Rank.DRAW_TWO) && (hand[i].getColor()) == upCard.getColor())) {
                        return i;
                    }
                }
            }
        }
         //���ڰ� ������ (���� ���� ���߿��� ���ڳ�������)     
    int hand_y=0;
    int hand_g=0;
    int hand_b=0;
    int hand_r=0;
    //���� ��
    for(int i = 0; i < hand.length; i++){
      if(hand[i].getColor() == Color.YELLOW){
        hand_y++;
      }else if(hand[i].getColor() == Color.GREEN){
        hand_g++;
      }else if(hand[i].getColor() == Color.BLUE){
        hand_b++;
      }else if(hand[i].getColor() == Color.RED){
        hand_r++;
      }
    }
    Color color1 = Color.NONE;
    if(hand_y >= hand_b && hand_y >= hand_g && hand_y >= hand_r){
      color1 = Color.YELLOW;  
    }else if( hand_b >=  hand_y &&  hand_b >=  hand_g &&  hand_b >=  hand_r){
      color1 = Color.BLUE;
    }else if( hand_g >= hand_b &&  hand_g >= hand_y &&  hand_g >= hand_r){
      color1 = Color.GREEN;
    }else if(hand_r >=  hand_b &&  hand_r >= hand_g && hand_r >=  hand_y ){
      color1 = Color.RED;
    }
        if((upCard.getRank() == UnoPlayer.Rank.WILD || upCard.getRank() == UnoPlayer.Rank.WILD_D4) )
        {
            for(int i = 0; i < hand.length; i++)
            {
                if(hand[i].getColor() != color1)
                    continue;
                if((hand[i].getRank() == Rank.DRAW_TWO || hand[i].getRank() == Rank.SKIP || hand[i].getRank() == Rank.REVERSE)&& (upCard.getColor() == hand[i].getColor() || hand[i].getColor() ==  calledColor))
                    return i;

            }
        }
        if(upCard.getRank() == Rank.DRAW_TWO || upCard.getRank() == Rank.SKIP || upCard.getRank() == Rank.REVERSE)
        {
          for(int i = 0; i < hand.length; i++)
          {
            if(upCard.getColor() != color1)
            {
              if(upCard.getRank() == hand[i].getRank())
                return i;
              continue;
            }
            if(hand[i].getColor() != color1)
              continue;
            if(hand[i].getRank() == Rank.DRAW_TWO || hand[i].getRank() == Rank.SKIP || hand[i].getRank() == Rank.REVERSE)
              return i;
          
          }
          
        }
        if(upCard.getRank() == Rank.NUMBER)
        {
          for(int i = 0; i < hand.length; i++)
          {
            if(upCard.getColor() != color1)
            {
              if(upCard.getNumber() == hand[i].getNumber())
                return i;
              continue;
            }
            if(hand[i].getColor() != color1)
              continue;
            if(hand[i].getRank() == Rank.DRAW_TWO || hand[i].getRank() == Rank.SKIP || hand[i].getRank() == Rank.REVERSE)
              return i;
          }
        }
    //���ϵ� ����, ��� �ִ��� �ȵ�� �ִ��� ,      0 or 1
    int y_hand[] = new int[13];
    int g_hand[] = new int[13];
    int b_hand[] = new int[13];
    int r_hand[] = new int[13]; 
    if(hand_y > hand_b && hand_y > hand_g && hand_y > hand_r){
      color1 = Color.YELLOW;
      for(int i=0;i<hand.length;i++){
        if(hand[i].getColor() == Color.YELLOW && hand[i].getRank() == Rank.NUMBER){
          y_hand[hand[i].getNumber()]++;
        }else if(hand[i].getColor() == Color.YELLOW && hand[i].getRank() == Rank.SKIP){
           y_hand[10]++;
        }else if(hand[i].getColor() == Color.YELLOW && hand[i].getRank() == Rank.REVERSE){
          y_hand[11]++;
        }else if(hand[i].getColor() == Color.YELLOW && hand[i].getRank() == Rank.DRAW_TWO){
          y_hand[12]++;
        }
      }
    }else if( hand_b >  hand_y &&  hand_b >  hand_g &&  hand_b >  hand_r){
      color1 = Color.BLUE;
      for(int i=0;i<hand.length;i++){
        if(hand[i].getColor() == Color.BLUE && hand[i].getRank() == Rank.NUMBER){
          b_hand[hand[i].getNumber()]++;
        }else if(hand[i].getColor() == Color.BLUE && hand[i].getRank() == Rank.SKIP){
          b_hand[10]++;
        }else if(hand[i].getColor() == Color.BLUE && hand[i].getRank() == Rank.REVERSE){
          b_hand[11]++;
        }else if(hand[i].getColor() == Color.BLUE && hand[i].getRank() == Rank.DRAW_TWO){
          b_hand[12]++;
        }
      }
    }else if( hand_g > hand_b &&  hand_g > hand_y &&  hand_g > hand_r){
      color1 = Color.GREEN;
      for(int i=0;i<hand.length;i++){
        if(hand[i].getColor() == Color.GREEN && hand[i].getRank() == Rank.NUMBER){
          g_hand[hand[i].getNumber()]++;
        }else if(hand[i].getColor() == Color.GREEN && hand[i].getRank() == Rank.SKIP){
          g_hand[10]++;
        }else if(hand[i].getColor() == Color.GREEN && hand[i].getRank() == Rank.REVERSE){
          g_hand[11]++;
        }else if(hand[i].getColor() == Color.GREEN && hand[i].getRank() == Rank.DRAW_TWO){
          g_hand[12]++;
        }
      }
      
    }else if(hand_r >  hand_b &&  hand_r >  hand_g && hand_r >  hand_y ){
      color1 = Color.RED;
      for(int i=0;i<hand.length;i++){
        if(hand[i].getColor() == Color.RED && hand[i].getRank() == Rank.NUMBER){
          r_hand[hand[i].getNumber()]++;
        }else if(hand[i].getColor() == Color.RED && hand[i].getRank() == Rank.SKIP){
          r_hand[10]++;
        }else if(hand[i].getColor() == Color.RED && hand[i].getRank() == Rank.REVERSE){
          r_hand[11]++;
        }else if(hand[i].getColor() == Color.RED && hand[i].getRank() == Rank.DRAW_TWO){
          r_hand[12]++;
        }
      }
    }
    
    if(color1 == Color.YELLOW && (upCard.getColor()== Color.YELLOW || Color.YELLOW == calledColor)){
      for(int i=12;i>0;i--){
        if(y_hand[10] >= 1){
           for(int j=0;j<hand.length;j++){
            if(hand[j].getRank() == Rank.SKIP&& hand[j].getColor() == color1){
              return j;
            }
          }
        }else if(y_hand[11]>= 1){
          for(int j=0;j<hand.length;j++){
            if(hand[j].getRank() == Rank.REVERSE&& hand[j].getColor() == color1){
              return j;
            }
          }
        }else if(y_hand[12]>= 1){
          for(int j=0;j<hand.length;j++){
            if(hand[j].getRank() == Rank.DRAW_TWO&& hand[j].getColor() == color1){
              return j;
            }
          }
        }else if(y_hand[i]>=1){
          for(int j=0;j<hand.length;j++){
            if(hand[j].getNumber() == i && hand[j].getColor() == color1){
              return j;
            }
          }
        }
      }
    }else if(color1 == Color.BLUE && (upCard.getColor()== Color.BLUE || Color.BLUE == calledColor)){
      for(int i=12;i>0;i--){
        if(b_hand[10] >= 1){
           for(int j=0;j<hand.length;j++){
            if(hand[j].getRank() == Rank.SKIP&& hand[j].getColor() == color1){
              return j;
            }
          }
        }else if(b_hand[11]>= 1){
          for(int j=0;j<hand.length;j++){
            if(hand[j].getRank() == Rank.REVERSE&& hand[j].getColor() == color1){
              return j;
            }
          }
        }else if(b_hand[12]>= 1){
          for(int j=0;j<hand.length;j++){
            if(hand[j].getRank() == Rank.DRAW_TWO&& hand[j].getColor() == color1){
              return j;
            }
          }
        }if(b_hand[i]>=1){
          for(int j=0;j<hand.length;j++){
            if(hand[j].getNumber() == i&& hand[j].getColor() == color1){
              return j;
            }
          }
        }
      }
    }else if(color1 == Color.GREEN && (upCard.getColor()== Color.GREEN || Color.GREEN == calledColor)){
      for(int i=12;i>0;i--){
        if(g_hand[10] >= 1){
           for(int j=0;j<hand.length;j++){
            if(hand[j].getRank() == Rank.SKIP&& hand[j].getColor() == color1){
              return j;
            }
          }
        }else if(g_hand[11]>= 1){
          for(int j=0;j<hand.length;j++){
            if(hand[j].getRank() == Rank.REVERSE&& hand[j].getColor() == color1){
              return j;
            }
          }
        }else if(g_hand[12]>= 1){
          for(int j=0;j<hand.length;j++){
            if(hand[j].getRank() == Rank.DRAW_TWO&& hand[j].getColor() == color1){
              return j;
            }
          }
        }else if(g_hand[i]>=1){
          for(int j=0;j<hand.length;j++){
            if(hand[j].getNumber() == i&& hand[j].getColor() == color1){
              return j;
            }
          }
        }
      }
    }else if(color1 == Color.RED && (upCard.getColor()== Color.RED || Color.RED == calledColor)){
      for(int i=12;i>0;i--){
        
        if(r_hand[10] >= 1){
           for(int j=0;j<hand.length;j++){
            if(hand[j].getRank() == Rank.SKIP&& hand[j].getColor() == color1){
              return j;
            }
          }
        }else if(r_hand[11]>= 1){
          for(int j=0;j<hand.length;j++){
            if(hand[j].getRank() == Rank.REVERSE&& hand[j].getColor() == color1){
              return j;
            }
          }
        }else if(r_hand[12]>= 1){
          for(int j=0;j<hand.length;j++){
            if(hand[j].getRank() == Rank.DRAW_TWO&& hand[j].getColor() == color1){
              return j;
            }
          }
        }else if(r_hand[i]>=1){
          for(int j=0;j<hand.length;j++){
            if(hand[j].getNumber() == i&& hand[j].getColor() == color1){
              return j;
            }
          }
        }
        
      }
    }
        int max=0;
        for(int i = 0; i < hand.length; i++){
          if((hand[i].getColor()== upCard.getColor()) || (hand[i].getNumber() == upCard.getNumber())){
            if(max<hand[i].getNumber()){  
              max = hand[i].getNumber();
                }
            }
        }
        for(int i=0;i<hand.length;i++){
            if((hand[i].getColor()== upCard.getColor()) || (hand[i].getNumber() == upCard.getNumber())&&(hand[i].getNumber() == max)){
                return i;
            }
        }
        for(int i = 0; i < hand.length; i++){
            if(((hand[i].getColor()== upCard.getColor()) || (hand[i].getRank() == upCard.getRank()))){
                if((hand[i].getNumber() == upCard.getNumber())&& (hand[i].getRank() == upCard.getRank())){
                  return i;
                }
            }
        }
        
        //�߰�
        if((state.getNumCardsInHandsOfUpcomingPlayers()[0]<state.getNumCardsInHandsOfUpcomingPlayers()[2]) || ((state.getNumCardsInHandsOfUpcomingPlayers()[0]<5) && (state.getTotalScoreOfUpcomingPlayers()[0]<25))){
        for(int i = 0; i < hand.length; i++){
            if((state.getNumCardsInHandsOfUpcomingPlayers()[0]<state.getNumCardsInHandsOfUpcomingPlayers()[2])&&((hand[i].getColor()== upCard.getColor()) && hand[i].getRank() == Rank.REVERSE)){
                return i;
            }else if((hand[i].getRank() == Rank.WILD_D4)){
              return i;
            }else if((hand[i].getColor()== upCard.getColor())&& (hand[i].getRank() == Rank.DRAW_TWO)){
              return i;
            }else if((hand[i].getColor()== upCard.getColor()) && hand[i].getRank() == Rank.SKIP){
              return i;
            }
        }
        }

        
        //basic
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getRank() == Rank.WILD_D4)){
              return i;
            }
        }
        for(int i = 0; i < hand.length; i++){
            if(hand[i].getRank() == Rank.WILD){
                return i;
            }
        }  
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getColor()== upCard.getColor())&& (hand[i].getRank() == Rank.DRAW_TWO)){
                return i;
            }
        }   
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getColor()== upCard.getColor()) && hand[i].getRank() == Rank.SKIP){
                return i;
            }
        } 
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getColor()== upCard.getColor()) && hand[i].getRank() == Rank.REVERSE){
                return i;
            }
        }
        
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getRank() == upCard.getRank()) && (hand[i].getNumber() == upCard.getNumber())){
                return i;
            }else if((hand[i].getRank() == upCard.getRank())&&(hand[i].getColor() == upCard.getColor())){
              return i;
            }  
        }
         
        for(int i = 0; i < hand.length; i++){
            if(hand[i].getColor() == upCard.getColor() || hand[i].getColor() == calledColor){
                return i; 
            }else if(hand[i].getRank() == Rank.NUMBER){
                if(hand[i].getNumber() == upCard.getNumber()){
                    return i;
                }
            }else if(hand[i].getRank() == upCard.getRank()){
                if(upCard.getRank() == Rank.DRAW_TWO || upCard.getRank() == Rank.REVERSE || upCard.getRank() == Rank.SKIP
                     || upCard.getRank() == Rank.WILD || upCard.getRank() == Rank.WILD_D4){
                    return i;
                }
            }
        }
        return -1;
 }
    public Color callColor(Card[] hand) {

        int ycount =0;
        int bcount =0;
        int gcount =0;
        int rcount =0; 
        for(int i=0;i<hand.length;i++){
            if(hand[i].getColor() == Color.YELLOW){
                ycount++;
            }else if(hand[i].getColor() == Color.BLUE){
                bcount++;
            }else if(hand[i].getColor() == Color.GREEN){
                gcount++;
            }else if(hand[i].getColor() == Color.RED){
                rcount++;
            }
        }
        int max =0;
        max = Math.max(rcount,Math.max(gcount,Math.max(ycount,bcount)));
        if(max ==ycount){
            return Color.YELLOW;
        }else if(max ==bcount){
            return Color.BLUE;
        }else if(max ==gcount){
            return Color.GREEN;
        }else{
            return Color.RED;
        }
    }
}