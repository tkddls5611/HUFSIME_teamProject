
public class test2_UnoPlayer implements UnoPlayer {

    public int play(Card[] hand, Card upCard, Color calledColor, GameState state) {
      // 1.������� ī�尹���� 3�����ϰ� �� ��������� ī�尹���� 3�庸�� ������ draw2 �� skip
        if(state.getNumCardsInHandsOfUpcomingPlayers()[0] <= 3 && state.getNumCardsInHandsOfUpcomingPlayers()[1] > 3){
            for(int i = 0; i < hand.length; i++){
                if((hand[i].getRank() == Rank.DRAW_TWO) && (hand[i].getColor() == upCard.getColor())
                      || (hand[i].getRank() == Rank.SKIP) && (hand[i].getColor() == upCard.getColor())){
                    return i;
                }
            }//2. ��������� �� ������� ī�尹���� �Ѵ� 3�� �����̸� reverse �� wild �� wild4
        }else if(state.getNumCardsInHandsOfUpcomingPlayers()[0] <= 3 && state.getNumCardsInHandsOfUpcomingPlayers()[1] <= 3){ //2
            for(int i = 0; i < hand.length; i++){
                if(((hand[i].getRank() == Rank.REVERSE) && (hand[i].getColor() == upCard.getColor()))
                     || hand[i].getRank() == Rank.WILD || hand[i].getRank() == Rank.WILD_D4){
                    return i;
                }
            }
        }
        //PRELIMINARIES: Determine # of all colors in my hand.
        int totalRed = 0;
        int totalBlue = 0;
        int totalYellow = 0;
        int totalGreen = 0;
        int totalPain = 0;
        for (int i = 0; i < hand.length; i++){
            switch (hand[i].getColor()){
                case RED:
                    totalRed++;
                    break;
                case BLUE:
                    totalBlue++;
                    break;
                case YELLOW:
                    totalYellow++;
                    break;
                case GREEN:
                    totalGreen++;
                    break;
                case NONE:
                    totalPain++;
                    break;
            }
        }
        //Count the number of cards in play.
        int ofGreen[] = new int[25];
        int ofRed[] = new int[25];
        int ofBlue[] = new int[25];
        int ofYellow[] = new int[25];
        int ofWild[] = new int[8];

        for (int i = 0; i < state.getPlayedCards().length; i++){
            if (state.getPlayedCards()[i].getColor() == Color.RED){
                if (state.getPlayedCards()[i].getNumber() != -1){
                    ofRed[state.getPlayedCards()[i].getNumber()]++;
                }
                if (state.getPlayedCards()[i].getRank() == Rank.SKIP){
                    ofRed[10]++;
                }
                if (state.getPlayedCards()[i].getRank() == Rank.REVERSE){
                    ofRed[11]++;
                }
                if (state.getPlayedCards()[i].getRank() == Rank.DRAW_TWO){
                    ofRed[12]++;
                }
            }
            if (state.getPlayedCards()[i].getColor() == Color.GREEN){
                if (state.getPlayedCards()[i].getNumber() != -1){
                    ofGreen[state.getPlayedCards()[i].getNumber()]++;
                }
                if (state.getPlayedCards()[i].getRank() == Rank.SKIP){
                    ofGreen[10]++;
                }
                if (state.getPlayedCards()[i].getRank() == Rank.REVERSE){
                    ofGreen[11]++;
                }
                if (state.getPlayedCards()[i].getRank() == Rank.DRAW_TWO){
                    ofGreen[12]++;
                }
            }
            if (state.getPlayedCards()[i].getColor() == Color.BLUE){
                if (state.getPlayedCards()[i].getNumber() != -1){
                    ofBlue[state.getPlayedCards()[i].getNumber()]++;
                }
                if (state.getPlayedCards()[i].getRank() == Rank.SKIP){
                    ofBlue[10]++;
                }
                if (state.getPlayedCards()[i].getRank() == Rank.REVERSE){
                    ofBlue[11]++;
                }
                if (state.getPlayedCards()[i].getRank() == Rank.DRAW_TWO){
                    ofBlue[12]++;
                }
            }
            if (state.getPlayedCards()[i].getColor() == Color.YELLOW){
                if (state.getPlayedCards()[i].getNumber() != -1){
                    ofYellow[state.getPlayedCards()[i].getNumber()]++;
                }
                if (state.getPlayedCards()[i].getRank() == Rank.SKIP){
                    ofYellow[10]++;
                }
                if (state.getPlayedCards()[i].getRank() == Rank.REVERSE){
                    ofYellow[11]++;
                }
                if (state.getPlayedCards()[i].getRank() == Rank.DRAW_TWO){
                    ofYellow[12]++;
                }
            }
            if (state.getPlayedCards()[i].getRank() == Rank.WILD){
                ofWild[0]++;
            }
            if (state.getPlayedCards()[i].getRank() == Rank.WILD_D4){
                ofWild[1]++;
            }
        }

        //CALCULATE THE NUMBER OF UNKNOWABLE CARDS.
        int cardsUnknown = 0;
        cardsUnknown = 108 - (state.getPlayedCards().length + hand.length);

  UnoPlayer.Color upCardColor = upCard.getColor();
        //Handle the most recent called color.
        if (calledColor != UnoPlayer.Color.NONE){
            upCardColor = calledColor;
        }

        //Calculate the average number of cards in a hand.
        double averageHand = 0;
  int[] upcomingPlayerCards = state.getNumCardsInHandsOfUpcomingPlayers();
        for (int b = 0; b < upcomingPlayerCards.length; b++){
            averageHand += upcomingPlayerCards[b];
        }
        averageHand = averageHand / upcomingPlayerCards.length;
        
//-----------------------------------------------------------------------------
//..NUMBER CARDS...............................................................
//-----------------------------------------------------------------------------
        double highestCardRank = 0;
        int which = -100;
        double ratio = 0;
        for (int i = 0; i < hand.length; i++){
            double currentCardRank = 0;
//Color is the same && card is a number
   Card current = hand[i];
            if ((current.getColor() == upCardColor) && (current.getRank() == UnoPlayer.Rank.NUMBER)){
                currentCardRank += (10 + current.getNumber());
                if (current.getNumber() != 0 && current.getNumber() != 1){
                    int b = current.getNumber();
                    currentCardRank -= ((8 - (ofRed[b] + ofBlue[b] + ofGreen[b] + ofYellow[b]))/2);
                }
                if (current.getNumber() == 0){
                    currentCardRank -= ((4 - (ofRed[0] + ofBlue[0] + ofGreen[0] + ofYellow[0]))/2);
                }
                switch (current.getColor()){
                case RED:
                    currentCardRank += (hand.length / totalRed);
                    ratio = colorRatio(ofRed, totalRed, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                case BLUE:
                    currentCardRank += (hand.length / totalBlue);
                    ratio = colorRatio(ofBlue, totalBlue, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                case GREEN:
                    currentCardRank += (hand.length / totalGreen);
                    ratio = colorRatio(ofGreen, totalGreen, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                case YELLOW:
                    currentCardRank += (hand.length / totalYellow);
                    ratio = colorRatio(ofYellow, totalYellow, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                }
            }

//Number is the same, color is different
            if ((current.getNumber() != -1) && (current.getNumber() == upCard.getNumber())
                    && (current.getColor() != upCard.getColor())){
                currentCardRank += (10 + current.getNumber());
                if (current.getNumber() != 0 && current.getNumber() != 1){
                    int b = current.getNumber();
                    currentCardRank -= ((8 - (ofRed[b] + ofBlue[b] + ofGreen[b] + ofYellow[b]))/2);
                }
                if (current.getNumber() == 0){
                    currentCardRank -= ((4 - (ofRed[0] + ofBlue[0] + ofGreen[0] + ofYellow[0]))/2);
                }
                switch (current.getColor()){
                case RED:
                    currentCardRank += (hand.length / totalRed);
                    ratio = colorRatio(ofRed, totalRed, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                case BLUE:
                    currentCardRank += (hand.length / totalBlue);
                    ratio = colorRatio(ofBlue, totalBlue, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                case GREEN:
                    currentCardRank += (hand.length / totalGreen);
                    ratio = colorRatio(ofGreen, totalGreen, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                case YELLOW:
                    currentCardRank += (hand.length / totalYellow);
                    ratio = colorRatio(ofYellow, totalYellow, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                }
            }

//-----------------------------------------------------------------------------
//..CARDS OF PAIN AND SUFFERING................................................
//-----------------------------------------------------------------------------

//Color is the same && card is a reverse
            if ((current.getRank() == Rank.REVERSE) && (current.getColor() == upCardColor)){
                currentCardRank += 15;
                if (upcomingPlayerCards[2] < averageHand){
                    currentCardRank+= 5;
                }
                currentCardRank -= ((8 - (ofRed[11] + ofBlue[11] + ofGreen[11] + ofYellow[11]))/2);
                switch (current.getColor()){
                case RED:
                    ratio = colorRatio(ofRed, totalRed, cardsUnknown);
                    if (ratio != 0){
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalRed))/2;
                    currentCardRank -= (upcomingPlayerCards[2] * ratio);
                    }
                    break;
                case BLUE:                    
                    ratio = colorRatio(ofBlue, totalBlue, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalBlue))/2;
                    currentCardRank -= (upcomingPlayerCards[2] * ratio);
                    break;
                case GREEN:
                    ratio = colorRatio(ofGreen, totalGreen, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalGreen))/2;
                    currentCardRank -= (upcomingPlayerCards[2] * ratio);
                    break;
                case YELLOW:
                    ratio = colorRatio(ofYellow, totalYellow, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalYellow))/2;
                    currentCardRank -= (upcomingPlayerCards[2] * ratio);
                    break;
                }
            }
            
//Color is different && card is a reverse
            if ((current.getRank() == Rank.REVERSE) && (current.getRank() == upCard.getRank()) 
                    && (current.getColor() != upCard.getColor())){
                currentCardRank += 15;
                if (upcomingPlayerCards[2] < averageHand){
                    currentCardRank+= 5;
                }
                currentCardRank -= ((8 - (ofRed[11] + ofBlue[11] + ofGreen[11] + ofYellow[11]))/2);
                switch (current.getColor()){
                case RED:
                    ratio = colorRatio(ofRed, totalRed, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalRed))/2;
                    currentCardRank -= (upcomingPlayerCards[2] * ratio);
                    break;
                case BLUE:                    
                    ratio = colorRatio(ofBlue, totalBlue, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalBlue))/2;
                    currentCardRank -= (upcomingPlayerCards[2] * ratio);
                    break;
                case GREEN:
                    ratio = colorRatio(ofGreen, totalGreen, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalGreen))/2;
                    currentCardRank -= (upcomingPlayerCards[2] * ratio);
                    break;
                case YELLOW:
                    ratio = colorRatio(ofYellow, totalYellow, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalYellow))/2;
                    currentCardRank -= (upcomingPlayerCards[2] * ratio);
                    break;
                }
            }  
            
//Color is the same && card is a skip
            if ((current.getRank() == Rank.SKIP) && (current.getColor() == upCardColor)){
                currentCardRank += 15;
                if (upcomingPlayerCards[1] < averageHand){
                    currentCardRank+= 5;
                }
                currentCardRank -= ((8 - (ofRed[10] + ofBlue[10] + ofGreen[10] + ofYellow[10]))/2);
                switch (current.getColor()){
                case RED:
                    ratio = colorRatio(ofRed, totalRed, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalRed))/2;
                    currentCardRank -= (upcomingPlayerCards[1] * ratio);
                    break;
                case BLUE:                    
                    ratio = colorRatio(ofBlue, totalBlue, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalBlue))/2;
                    currentCardRank -= (upcomingPlayerCards[1] * ratio);
                    break;
                case GREEN:
                    ratio = colorRatio(ofGreen, totalGreen, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalGreen))/2;
                    currentCardRank -= (upcomingPlayerCards[1] * ratio);
                    break;
                case YELLOW:
                    ratio = colorRatio(ofYellow, totalYellow, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalYellow))/2;
                    currentCardRank -= (upcomingPlayerCards[1] * ratio);
                    break;
                }

            }
//Card is a skip && color is different
            if ((current.getRank() == Rank.SKIP) && (current.getRank() == upCard.getRank()) &&
                    (current.getColor() != upCard.getColor())){
                currentCardRank += 15;
                if (upcomingPlayerCards[1] < averageHand){
                    currentCardRank+= 5;
                }
                currentCardRank -= ((8 - (ofRed[10] + ofBlue[10] + ofGreen[10] + ofYellow[10]))/2);
                switch (current.getColor()){
                case RED:
                    ratio = colorRatio(ofRed, totalRed, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalRed))/2;
                    currentCardRank -= (upcomingPlayerCards[1] * ratio);
                    break;
                case BLUE:                    
                    ratio = colorRatio(ofBlue, totalBlue, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalBlue))/2;
                    currentCardRank -= (upcomingPlayerCards[1] * ratio);
                    break;
                case GREEN:
                    ratio = colorRatio(ofGreen, totalGreen, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalGreen))/2;
                    currentCardRank -= (upcomingPlayerCards[1] * ratio);
                    break;
                case YELLOW:
                    ratio = colorRatio(ofYellow, totalYellow, cardsUnknown);
                    currentCardRank += ((upcomingPlayerCards[0] * ratio)+
                            (hand.length / totalYellow))/2;
                    currentCardRank -= (upcomingPlayerCards[1] * ratio);
                    break;
                }

            }
//Color is the same & card is a D2
            if ((current.getRank() == Rank.DRAW_TWO) && (current.getColor() == upCardColor)){
                currentCardRank += (15 - (upcomingPlayerCards[0]/3));
                if (upcomingPlayerCards[0] < averageHand){
                    currentCardRank+= 5;
                }
                currentCardRank -= ((8 - (ofRed[12] + ofBlue[12] + ofGreen[12] + ofYellow[12]))/2);
                switch (current.getColor()){
                case RED:
                    ratio = colorRatio(ofRed, totalRed, cardsUnknown);
                    currentCardRank += (hand.length / totalRed);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                case BLUE:
                    ratio = colorRatio(ofBlue, totalBlue, cardsUnknown);
                    currentCardRank += (hand.length / totalBlue);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                case GREEN:
                    currentCardRank += (hand.length / totalGreen);
                    ratio = colorRatio(ofGreen, totalGreen, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                case YELLOW:
                    currentCardRank += (hand.length / totalYellow);
                    ratio = colorRatio(ofYellow, totalYellow, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                }

            }            
//Card is a D2 && color is different
            if ((current.getRank() == Rank.DRAW_TWO) && (current.getRank() == upCard.getRank()) && 
                    (current.getColor() != upCard.getColor())){
                currentCardRank += (15 - (upcomingPlayerCards[0]/3));
                if (upcomingPlayerCards[0] < averageHand){
                    currentCardRank+= 5;
                }
                currentCardRank -= ((8 - (ofRed[12] + ofBlue[12] + ofGreen[12] + ofYellow[12]))/2);
                switch (current.getColor()){
                case RED:
                    currentCardRank += (hand.length / totalRed);
                    ratio = colorRatio(ofRed, totalRed, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                case BLUE:
                    currentCardRank += (hand.length / totalBlue);
                    ratio = colorRatio(ofBlue, totalBlue, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                case GREEN:
                    currentCardRank += (hand.length / totalGreen);
                    ratio = colorRatio(ofGreen, totalGreen, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                case YELLOW:
                    currentCardRank += (hand.length / totalYellow);
                    ratio = colorRatio(ofYellow, totalYellow, cardsUnknown);
                    currentCardRank -= (upcomingPlayerCards[0] * ratio);
                    break;
                }

            }            
//Hello World! I mean, uh, Wild!
            if (current.getRank() == UnoPlayer.Rank.WILD){
                currentCardRank += 6;
                currentCardRank -= (4 - ofWild[0])/2;
            }
            if (current.getRank() == UnoPlayer.Rank.WILD_D4){
                currentCardRank += 5;
                if (upcomingPlayerCards[0] < averageHand){
                    currentCardRank+= 5;
                    currentCardRank -= (4 - ofWild[1])/2;
                }
            }
//Determine if current card is better than the best card found thus far
            if (currentCardRank > highestCardRank){
                highestCardRank = currentCardRank;
                which = i;
            }
        
    } //end for loop
if (which == -100){
    return -1;
}
 else
     return which;
} //end method

    private static double colorRatio(int ofColor[], int myTotalColor, int cardsUnknown){
        double totalPlayed = 0;
        double ratio = 0.00;
        //Count the number of cards of that color that have been played.
        for (int i = 0; i < ofColor.length; i++){
            totalPlayed += ofColor[i];
        }
        //Find the number remaining in every color and divide it by the number of
        //cards remaining?
        totalPlayed = 25 - (totalPlayed + myTotalColor);
        ratio = (totalPlayed / cardsUnknown);

        return ratio;
    }

    public Color callColor(Card[] hand) {

        int ycount =0;
        int ysum=0;
        int bcount =0;
        int bsum=0;
        int gcount =0;
        int gsum=0;
        int rcount =0; 
        int rsum=0;
        
        for(int i=0;i<hand.length;i++){
            if(hand[i].getColor() == Color.YELLOW){
                ycount++;
                ysum += hand[i].getNumber();
            }else if(hand[i].getColor() == Color.BLUE){
                bcount++;
                bsum +=hand[i].getNumber();
            }else if(hand[i].getColor() == Color.GREEN){
                gcount++;
                gsum +=hand[i].getNumber();
            }else if(hand[i].getColor() == Color.RED){
                rcount++;
                rsum +=hand[i].getNumber();
            }
        }
        
        int max =0;
        max = Math.max(rcount,Math.max(gcount,Math.max(ycount,bcount)));
        if(max ==ycount){
          
            if(ycount ==bcount){
                if(Math.max(ysum,bsum) == bsum) return Color.BLUE;
            }else if(ycount ==gcount){
                if(Math.max(ysum,gsum) ==gsum) return Color.GREEN;
            }else if(ycount ==rcount){
                if(Math.max(ysum,rsum) == rsum) return Color.RED;
            }else return Color.YELLOW;
            
        }else if(max ==bcount){
          
            if(bcount ==ycount){
                if(Math.max(bsum,ysum) == ysum) return Color.YELLOW;
            }else if(bcount ==gcount){
                if(Math.max(bsum,gsum) ==gsum) return Color.GREEN;
            }else if(bcount ==rcount){
                if(Math.max(bsum,rsum) == rsum) return Color.RED;
            }else return Color.BLUE;
            
        }else if(max ==gcount){
          
            if(gcount ==ycount){
                if(Math.max(gsum,ysum) == ysum) return Color.YELLOW;
            }else if(bcount ==gcount){
                if(Math.max(gsum,bsum) ==bsum) return Color.BLUE;
            }else if(bcount ==rcount){
                if(Math.max(gsum,rsum) == rsum) return Color.RED;
            }else return Color.GREEN;
            
        }else{
            if(rcount ==ycount){
                if(Math.max(rsum,ysum) == ysum) return Color.YELLOW;
            }else if(bcount ==gcount){
                if(Math.max(rsum,gsum) ==gsum) return Color.GREEN;
            }else if(bcount ==rcount){
                if(Math.max(rsum,bsum) == bsum) return Color.BLUE;
            }else return Color.RED;
        }
        return Color.RED;
    }

}
