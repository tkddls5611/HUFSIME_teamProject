import java.util.ArrayList;
public class S12_UnoPlayer implements UnoPlayer {
//test ok
    public int play(Card[] hand, Card upCard, Color calledColor, GameState state) {
  
        if(state.getNumCardsInHandsOfUpcomingPlayers()[0] <= 3 && state.getNumCardsInHandsOfUpcomingPlayers()[1] > 3){
            for(int i = 0; i < hand.length; i++){
                if((hand[i].getRank() == Rank.DRAW_TWO) && (hand[i].getColor() == upCard.getColor())
                      || (hand[i].getRank() == Rank.SKIP) && (hand[i].getColor() == upCard.getColor())){
                    return i;
                }
            }
        }else if(state.getNumCardsInHandsOfUpcomingPlayers()[0] <= 3 && state.getNumCardsInHandsOfUpcomingPlayers()[1] <= 3){
            for(int i = 0; i < hand.length; i++){
                if(((hand[i].getRank() == Rank.REVERSE) && (hand[i].getColor() == upCard.getColor()))
                     || hand[i].getRank() == Rank.WILD || hand[i].getRank() == Rank.WILD_D4){
                    return i;
                }
            }
        }
   //0.���ڰ� ���������ϱ� (���� ���� ���߿��� ���ڳ�������)     
      //���� ���� ���� �� ����
        int ycount =0;
        int bcount =0;
        int gcount =0;
        int rcount =0;
        ArrayList<Integer> yarray = new ArrayList<Integer>();
        ArrayList<Integer> barray = new ArrayList<Integer>();
        ArrayList<Integer> garray = new ArrayList<Integer>();
        ArrayList<Integer> rarray = new ArrayList<Integer>();
        
        for(int i=0;i<hand.length;i++){
            if(hand[i].getColor() == Color.YELLOW){
                ycount++;
                if(!(hand[i].getRank() ==Rank.SKIP || hand[i].getRank() ==Rank.REVERSE || hand[i].getRank() ==Rank.DRAW_TWO)) yarray.add(i);
            }else if(hand[i].getColor() == Color.BLUE){
                bcount++;
                if(!(hand[i].getRank() ==Rank.SKIP || hand[i].getRank() ==Rank.REVERSE || hand[i].getRank() ==Rank.DRAW_TWO)) barray.add(i);
            }else if(hand[i].getColor() == Color.GREEN){
                gcount++;
                if(!(hand[i].getRank() ==Rank.SKIP || hand[i].getRank() ==Rank.REVERSE || hand[i].getRank() ==Rank.DRAW_TWO)) garray.add(i);
            }else if(hand[i].getColor() == Color.RED){
                rcount++;
                if(!(hand[i].getRank() ==Rank.SKIP || hand[i].getRank() ==Rank.REVERSE || hand[i].getRank() ==Rank.DRAW_TWO)) rarray.add(i);
            }
        }
        int color_max =0;
        color_max = Math.max(rcount,Math.max(gcount,Math.max(ycount,bcount)));//�� ���帹�� �� = color_max
        if(color_max ==ycount){//���� ���� �� : �����
            int yfinal = hand[yarray.get(0)].getNumber();
            for(int i=0;i<yarray.size();i++){
                yfinal = Math.max(yfinal,hand[yarray.get(i)].getNumber());
            }
            for(int i=0;i<hand.length;i++){
                if(hand[i].getColor() ==Color.YELLOW || hand[i].getNumber() ==yfinal) return i;
            }
           
        }else if(color_max ==bcount){//���� ���� �� : �Ķ���
          int bfinal = hand[barray.get(0)].getNumber();
            for(int i=0;i<barray.size();i++){
                bfinal = Math.max(bfinal,hand[barray.get(i)].getNumber());
            }
            for(int i=0;i<hand.length;i++){
                if(hand[i].getColor() ==Color.BLUE || hand[i].getNumber() ==bfinal) return i;
                
            }
        }else if(color_max ==gcount){//���� ���� �� : �ʷϻ�
          int gfinal = hand[garray.get(0)].getNumber();
            for(int i=0;i<garray.size();i++){
                gfinal = Math.max(gfinal,hand[garray.get(i)].getNumber());
            }
            for(int i=0;i<hand.length;i++){
                if(hand[i].getColor() ==Color.GREEN || hand[i].getNumber() ==gfinal) return i;
                
            }
        }else if(color_max ==rcount){//���� ���� �� : ������
          int rfinal = hand[rarray.get(0)].getNumber();
            for(int i=0;i<rarray.size();i++){
                rfinal = Math.max(rfinal,hand[rarray.get(i)].getNumber());
            }
            for(int i=0;i<hand.length;i++){
                if(hand[i].getColor() ==Color.RED || hand[i].getNumber() ==rfinal) return i;
       
            }
            
        }

        
        //basic
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getRank() == Rank.WILD_D4)){
              return i;
            }
        }
        for(int i = 0; i < hand.length; i++){
            if(hand[i].getRank() == Rank.WILD){
                return i;
            }
        }  
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getColor()== upCard.getColor())&& (hand[i].getRank() == Rank.DRAW_TWO)){
                return i;
            }
        }   
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getColor()== upCard.getColor()) && hand[i].getRank() == Rank.SKIP){
                return i;
            }
        } 
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getColor()== upCard.getColor()) && hand[i].getRank() == Rank.REVERSE){
                return i;
            }
        }
        
        for(int i = 0; i < hand.length; i++){
            if((hand[i].getRank() == upCard.getRank()) && (hand[i].getNumber() == upCard.getNumber())){
                return i;
            }else if((hand[i].getRank() == upCard.getRank())&&(hand[i].getColor() == upCard.getColor())){
              return i;
            }  
        }
         
        for(int i = 0; i < hand.length; i++){
            if(hand[i].getColor() == upCard.getColor() || hand[i].getColor() == calledColor){
                return i; 
            }else if(hand[i].getRank() == Rank.NUMBER){
                if(hand[i].getNumber() == upCard.getNumber()){
                    return i;
                }
            }else if(hand[i].getRank() == upCard.getRank()){
                if(upCard.getRank() == Rank.DRAW_TWO || upCard.getRank() == Rank.REVERSE || upCard.getRank() == Rank.SKIP
                     || upCard.getRank() == Rank.WILD || upCard.getRank() == Rank.WILD_D4){
                    return i;
                }
            }
        }
        return -1;
 }
    public Color callColor(Card[] hand) {

        int ycount =0;
        int bcount =0;
        int gcount =0;
        int rcount =0; 
        for(int i=0;i<hand.length;i++){
            if(hand[i].getColor() == Color.YELLOW){
                ycount++;
            }else if(hand[i].getColor() == Color.BLUE){
                bcount++;
            }else if(hand[i].getColor() == Color.GREEN){
                gcount++;
            }else if(hand[i].getColor() == Color.RED){
                rcount++;
            }
        }
        int max =0;
        max = Math.max(rcount,Math.max(gcount,Math.max(ycount,bcount)));
        if(max ==ycount){
            return Color.YELLOW;
        }else if(max ==bcount){
            return Color.BLUE;
        }else if(max ==gcount){
            return Color.GREEN;
        }else{
            return Color.RED;
        }
    }
}