if (upCard.getRank() == Rank.NUMBER && upCard.getColor() == Color.RED) { 
        for(int i=0; i<hand.length; i++){
          if(hand[i].getColor()==Color.RED){
            if(hand[i].getNumber()>=max){
              max=hand[i].getNumber();
              a=i;
            }
          }
          else if(a==-1&&hand[i].getNumber()==upCard.getNumber()){
              a=i;
            }  
        }
        if(a==-1){
        for(int i=0; i<hand.length; i++){
          if(hand[i].getColor()==Color.NONE){
              a=i;
            }
          }
        }
          return a;
      }
int max = -1