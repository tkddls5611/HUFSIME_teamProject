import java.util.Arrays;
import java.awt.Color;  
public class MedianFilterPicture {         
    private Picture[] pics; // Pictures to apply the median filter     
    private int width; // width of the picture     
    private int height; // height of the picture     
    private Picture median_pic; // New picture after applying the median filter   
    public MedianFilterPicture(String[] pic_names) {
    
        pics = new Picture[pic_names.length];
        
        for (int i=0; i<pic_names.length; i++) {
            pics[i] = new Picture(pic_names[i]);
        }
        
        this.width = pics[0].width();
        this.height = pics[0].height();
        
        this.median_pic = new Picture(this.width, this.height);
    
    }
    
    private void applyMedianFilter() {
        for (int i=0; i<this.width; i++) {
            for (int j=0; j<this.height; j++) {
                Color[] colors = new Color[this.pics.length];
                for (int k=0; k<this.pics.length; k++) {
                    colors[k] = this.pics[k].get(i,j);
                }
                Color m_c = getMedianColor(colors);
                this.median_pic.set(i,j,m_c);
            }
            
        }
    
    }
    
    private Color getMedianColor(Color[] colors) {
        int[] reds = new int[colors.length];
        for (int i=0; i<colors.length; i++) {
            reds[i] = colors[i].getRed();
        }
        
        int m_r = getMedianNumber(reds);
        
        int[] greens = new int[colors.length];
        for (int i=0; i<colors.length; i++) {
            greens[i] = colors[i].getGreen();
        }
        
        int m_g = getMedianNumber(greens);
        
        int[] blues = new int[colors.length];
        for (int i=0; i<colors.length; i++) {
            blues[i] = colors[i].getBlue();
        }
        
        int m_b = getMedianNumber(blues);
        
        return new Color(m_r, m_g, m_b);
    
    }   
    
    
    private int getMedianNumber(int[] numbers) {
        Arrays.sort(numbers);
        
        int sum = 0;
        
        for (int i=0; i<numbers.length; i++) {
            sum += numbers[i];
        }
        
        return sum/numbers.length;
        
//        return numbers[numbers.length/2];
    } 
    
    public void show() {
        median_pic.show();
    }
    
    public static void main(String[] args) {
        
        MedianFilterPicture mfp = new MedianFilterPicture(args);
        
        mfp.applyMedianFilter();
        
        mfp.show();
        
        
    }
} 