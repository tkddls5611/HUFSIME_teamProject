public class StockQuote{ 
    public static void main(String[] args) {
        String name = "http://finance.yahoo.com/q?s=";
            In in = new In(name + args[0]);
            String input = in.readAll();
            int start    = input.indexOf("Last Trade:", 0);
            int from     = input.indexOf("<b>", start);
            int to       = input.indexOf("</b>", from);
            String price = input.substring(from + 3, to);
            StdOut.println(price); 
    } 
}