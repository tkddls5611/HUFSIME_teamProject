package javajava;

import javax.swing.JOptionPane;

class finalproject_201402308_�̻���_201400541_����� {

public static void main(String[] args) {
  /*Team member : 201402308 �̻���, 201400541 �����*/
 
 String choose = JOptionPane.showInputDialog(
      "Hi! This is a matrix calculator made by �̻���, �����.\n"+"Which one do you want to do?\n"+
   "1.Sum   2.Subtract   3.Sum diagonal   4.Product diagonal   5.Cayley-hamilton\n"+
   "6.Determinant   7.Constant times   8.Average   9.Count elements except zero   10.Multiplication");
 
    int CHOICE = Integer.parseInt(choose); 
    
 if(CHOICE == 1){
    //input rows and columns
  String ROW = JOptionPane.showInputDialog("Enter a number of rows");
       int row = Integer.parseInt(ROW);
  String COL = JOptionPane.showInputDialog("Enter a number of columns");
       int col = Integer.parseInt(COL);
 
       int A[][] = new int[row][col];
       int B[][] = new int[row][col];
       
       //random matrix?
       String ANS = JOptionPane.showInputDialog("If you want random matrix enter 1. If not, enter 2.");
       int ans = Integer.parseInt(ANS);
       
       //sum 
       if (ans == 1){
        random(A);
        random(B);
        print1(A);
        print2(B);
        int sum[][] = sum(A, B);
        printSUM(sum); 
       }
       else if (ans == 2){
        for(int i = 0 ; i < row ; i++ )
          for(int j = 0 ; j < col ; j++ )
           A[i][j] = Integer.parseInt(
             JOptionPane.showInputDialog(null, 
             "Enter " + A.length + " rows and "+ A[0].length + " columns for first matrix"));
           for(int i = 0 ; i < row ; i++ )
            for(int j = 0 ; j < col ; j++ )
             B[i][j] = Integer.parseInt(
             JOptionPane.showInputDialog(null, 
             "Enter " + B.length + " rows and "+ B[0].length + " columns for second matrix"));
          int sum[][] = sum(A, B);
          printSUM(sum);
       }
       else
        JOptionPane.showMessageDialog(null,"Enter 1 or 2. Please try again.");
    }   
 else if(CHOICE == 2){
       //input rows and columns
  String ROW = JOptionPane.showInputDialog("Enter a number of rows");
       int row = Integer.parseInt(ROW);
  String COL = JOptionPane.showInputDialog("Enter a number of columns");
       int col = Integer.parseInt(COL);
 
       int A[][] = new int[row][col];
       int B[][] = new int[row][col];
 
       //random matrix?
       String ANS = JOptionPane.showInputDialog("If you want random matrix enter 1. If not, enter 2.");
       int ans = Integer.parseInt(ANS);
       
       //subtract 
       if (ans == 1){
        random(A);
        random(B);
        print1(A);
        print2(B);
        int sub[][] = sub(A, B);
        printSUB(sub); 
       }
       else if (ans == 2){
        for(int i = 0 ; i < row ; i++ )
          for(int j = 0 ; j < col ; j++ )
           A[i][j] = Integer.parseInt(
             JOptionPane.showInputDialog(null, 
             "Enter " + A.length + " rows and "+ A[0].length + " columns for first matrix"));
           for(int i = 0 ; i < row ; i++ )
            for(int j = 0 ; j < col ; j++ )
             B[i][j] = Integer.parseInt(
             JOptionPane.showInputDialog(null, 
             "Enter " + B.length + " rows and "+ B[0].length + " columns for second matrix"));
          int sub[][] = sub(A, B);
          printSUB(sub);
       }
       else
        JOptionPane.showMessageDialog(null,"Enter 1 or 2. Please try again.");
 }
 else if (CHOICE == 3){
    //input row and column
    String ROWANDCOL = JOptionPane.showInputDialog("Enter a number of rows and columns");
       int rowandcol = Integer.parseInt(ROWANDCOL);

    int [][] A = new int[rowandcol][rowandcol];  

    //random matrix?
    String ANS = JOptionPane.showInputDialog("If you want random matrix enter 1. If not, enter 2.");
       int ans = Integer.parseInt(ANS);
    
       //sum diagonal 
       if (ans == 1){
        random(A);
        print(A);
        JOptionPane.showMessageDialog(null, "Diagonal sum : "+diagSum(A));
       }
       else if (ans == 2){
        for(int i = 0 ; i < A.length ; i++ )
          for(int j = 0 ; j < A[0].length ; j++ ){
           A[i][j] = Integer.parseInt(
             JOptionPane.showInputDialog(null, 
               "Enter " + A.length + " rows and "+ A[0].length + " columns"));
           }
        JOptionPane.showMessageDialog(null, "Diagonal sum : "+diagSum(A));
       }
       else
        JOptionPane.showMessageDialog(null,"Enter 1 or 2. Please try again.");
 }
 else if (CHOICE == 4){
    //input row and column
    String ROWANDCOL = JOptionPane.showInputDialog("Enter a number of rows and columns");
       int rowandcol = Integer.parseInt(ROWANDCOL);

    int [][] A = new int[rowandcol][rowandcol];  

    //random matrix?
    String ANS = JOptionPane.showInputDialog("If you want random matrix enter 1. If not, enter 2.");
       int ans = Integer.parseInt(ANS);
    
       //product diagonal
       if (ans == 1){
        random(A);
        print(A);
        JOptionPane.showMessageDialog(null, "Diagonal product : "+diagProduct(A));
       }
       else if (ans == 2){
        for(int i = 0 ; i < A.length ; i++ )
          for(int j = 0 ; j < A[0].length ; j++ ){
           A[i][j] = Integer.parseInt(
             JOptionPane.showInputDialog(null, 
               "Enter " + A.length + " rows and "+ A[0].length + " columns"));
           }
        JOptionPane.showMessageDialog(null, "Diagonal product : "+diagProduct(A));
       }
       else
        JOptionPane.showMessageDialog(null,"Enter 1 or 2. Please try again.");
 }
 else if (CHOICE == 5){  
    
    int [][] A = new int[2][2];
  
    //random matrix?
    String ANS = JOptionPane.showInputDialog("If you want random matrix enter 1. If not, enter 2.");
       int ans = Integer.parseInt(ANS);
    
    //cayley-hamilton theorem
    if (ans == 1){
        random(A);
        print(A);
        JOptionPane.showMessageDialog(null, "By cayley-hamilton theorem, the matrix satisfy next equation.\n"
                +cayleyhamiltonTheorem(A) + "\nE is a unit matrix.");
       }
    else if (ans == 2){
     for(int i = 0 ; i < A.length ; i++ )
          for(int j = 0 ; j < A[0].length ; j++ ){
           A[i][j] = Integer.parseInt(
             JOptionPane.showInputDialog(null, 
               "Enter " + A.length + " rows and "+ A[0].length + " columns"));
           }
     JOptionPane.showMessageDialog(null, "By cayley-hamilton theorem, the matrix satisfy next equation.\n"
           +cayleyhamiltonTheorem(A) + "\nE is a unit matrix.");
    }
    else
        JOptionPane.showMessageDialog(null,"Enter 1 or 2. Please try again.");
 }
 
 else if (CHOICE == 6){
    //input row and column
  String ROWANDCOL = JOptionPane.showInputDialog("Enter a number of rows and columns");
       int rowandcol = Integer.parseInt(ROWANDCOL);

    int [][] A = new int[rowandcol][rowandcol];  

    //random matrix?
    String ANS = JOptionPane.showInputDialog("If you want random matrix enter 1. If not, enter 2.");
       int ans = Integer.parseInt(ANS);
    
       //determinant
       if (ans == 1){
        random(A);
        print(A);
        JOptionPane.showMessageDialog(null, "Determinant : "+determinant(A, rowandcol));
       }
       else if (ans == 2){
        for(int i = 0 ; i < A.length ; i++ )
          for(int j = 0 ; j < A[0].length ; j++ ){
           A[i][j] = Integer.parseInt(
             JOptionPane.showInputDialog(null, 
               "Enter " + A.length + " rows and "+ A[0].length + " columns"));
           }
        JOptionPane.showMessageDialog(null, "Determinant : "+determinant(A, rowandcol));
       }
       else
        JOptionPane.showMessageDialog(null,"Enter 1 or 2. Please try again.");
 }
 else if (CHOICE == 7){
    //input row and column
  String ROW = JOptionPane.showInputDialog("Enter a number of rows");
       int row = Integer.parseInt(ROW);
  String COL = JOptionPane.showInputDialog("Enter a number of columns");
       int col = Integer.parseInt(COL);
       
       int A[][] = new int[row][col];
       String K = JOptionPane.showInputDialog("Enter a constant");
       int k = Integer.parseInt(K);
       
       //random matrix?
       String ANS = JOptionPane.showInputDialog("If you want random matrix enter 1. If not, enter 2.");
       int ans = Integer.parseInt(ANS);
    
       //constant
       if (ans == 1){
        random(A);
        print(A);
        int con[][] = con(A, k);
        printCON(con);
       }
       else if (ans == 2){
        for(int i = 0 ; i < A.length ; i++ )
          for(int j = 0 ; j < A[0].length ; j++ ){
           A[i][j] = Integer.parseInt(
             JOptionPane.showInputDialog(null, 
               "Enter " + A.length + " rows and "+ A[0].length + " columns"));
           }
        int con[][] = con(A, k);
        printCON(con);
       }
       else
        JOptionPane.showMessageDialog(null,"Enter 1 or 2. Please try again.");
 }
 else if (CHOICE == 8){
    //input row and column
  String ROW = JOptionPane.showInputDialog("Enter a number of rows");
       int row = Integer.parseInt(ROW);
  String COL = JOptionPane.showInputDialog("Enter a number of columns");
       int col = Integer.parseInt(COL);
       
       int A[][] = new int[row][col];
       double k = row*col;
       
       //random matrix?
       String ANS = JOptionPane.showInputDialog("If you want random matrix enter 1. If not, enter 2.");
       int ans = Integer.parseInt(ANS);
    
       //sum diagonal 
       if (ans == 1){
        random(A);
        print(A);
        JOptionPane.showMessageDialog(null, "Average of all elements : "+all(A)/k);
       }
       else if (ans == 2){
        for(int i = 0 ; i < A.length ; i++ )
          for(int j = 0 ; j < A[0].length ; j++ ){
           A[i][j] = Integer.parseInt(
             JOptionPane.showInputDialog(null, 
               "Enter " + A.length + " rows and "+ A[0].length + " columns"));
           }
        JOptionPane.showMessageDialog(null, "Average of all elements : "+all(A)/k);
       }
       else
        JOptionPane.showMessageDialog(null,"Enter 1 or 2. Please try again.");
 } 
 
 else if (CHOICE == 9){
    //input row and column
  String ROW = JOptionPane.showInputDialog("Enter a number of rows");
       int row = Integer.parseInt(ROW);
  String COL = JOptionPane.showInputDialog("Enter a number of columns");
       int col = Integer.parseInt(COL);

    int [][] A = new int[row][col];
    
       //random matrix?
    String ANS = JOptionPane.showInputDialog("If you want random matrix enter 1. If not, enter 2.");
       int ans = Integer.parseInt(ANS);
    
       //count except zero 
       if (ans == 1){
        random(A);
        print(A);
        JOptionPane.showMessageDialog(null,"The number of elements except zero : "+noZeroCount(A));
       }
       else if (ans == 2){
        for(int i = 0 ; i < A.length ; i++ )
          for(int j = 0 ; j < A[0].length ; j++ ){
           A[i][j] = Integer.parseInt(
             JOptionPane.showInputDialog(null, 
               "Enter " + A.length + " rows and "+ A[0].length + " columns"));
           }
        JOptionPane.showMessageDialog(null,"The number of elements  except zero : "+noZeroCount(A));
       }
       else
        JOptionPane.showMessageDialog(null,"Enter 1 or 2. Please try again.");
 }
 else if (CHOICE == 10){
    //input row and column
  String ROWSInA = JOptionPane.showInputDialog("Enter a number of rows in first matrix");
       int rowsInA = Integer.parseInt(ROWSInA);
     String COLUMNSInA = JOptionPane.showInputDialog("Enter a number of columns in first matrix / rows in second matrix");
       int columnsInA = Integer.parseInt(COLUMNSInA);
     String COLUMNSInB = JOptionPane.showInputDialog("Enter a number of columns in second matrix");
       int columnsInB = Integer.parseInt(COLUMNSInB);
     
       int[][] A = new int[rowsInA][columnsInA];
       int[][] B = new int[columnsInA][columnsInB];
       
       //random matrix?
       String ANS = JOptionPane.showInputDialog("If you want random matrix enter 1. If not, enter 2.");
       int ans = Integer.parseInt(ANS);
       
       //multiply
       if (ans == 1){
        random(A);
        random(B);
        print(A);
        print(B);
        int[][] C = multiply(A, B);
        printMUL(C);
       }
       else if (ans == 2){
        for(int i = 0 ; i < A.length ; i++ )
          for(int j = 0 ; j < A[0].length ; j++ ){
           A[i][j] = Integer.parseInt(
             JOptionPane.showInputDialog(null, 
             "Enter " + A.length + " rows and "+ A[0].length + " columns for first matrix."));
           }
           for(int i = 0 ; i < B.length ; i++ )
            for(int j = 0 ; j < B[0].length ; j++ )
             B[i][j] = Integer.parseInt(
             JOptionPane.showInputDialog(null, 
             "Enter " + B.length + " rows and "+ B[0].length + " columns for second matrix"));
        int[][] C = multiply(A, B);
        printMUL(C);
       }
       else
        JOptionPane.showMessageDialog(null,"Enter 1 or 2. Please try again.");
 }
 else
  JOptionPane.showMessageDialog(null,"Enter between 1~10. Please try again.");
}


public static void print(int[][] A){
 StringBuffer elements = new StringBuffer();
  for(int row = 0; row < A.length; row++){
   for(int col = 0; col < A[row].length; col++){
    elements.append(A[row][col]);
    elements.append("        ");
    }
   elements.append("\n");
   }
    JOptionPane.showMessageDialog(null, "-----Random Matrix-----\n"+elements.toString());
   }

public static void print1(int[][] A){
 StringBuffer elements = new StringBuffer();
  for(int row = 0; row < A.length; row++){
   for(int col = 0; col < A[row].length; col++){
    elements.append(A[row][col]);
    elements.append("     \t");
    }
   elements.append("\n");
   }
    JOptionPane.showMessageDialog(null, "-----First Matrix-----\n"+elements.toString());
   }

public static void print2(int[][] A){
 StringBuffer elements = new StringBuffer();
  for(int row = 0; row < A.length; row++){
   for(int col = 0; col < A[row].length; col++){
    elements.append(A[row][col]);
    elements.append("     \t");
    }
   elements.append("\n");
   }
    JOptionPane.showMessageDialog(null, "-----Second Matrix-----\n"+elements.toString());
   }

public static void printSUM(int[][] A){
 StringBuffer elements = new StringBuffer();
  for(int row = 0; row < A.length; row++){
   for(int col = 0; col < A[row].length; col++){
    elements.append(A[row][col]);
    elements.append("     \t");
    }
   elements.append("\n");
   }
    JOptionPane.showMessageDialog(null, "-----Sum Matrix-----\n"+elements.toString());
   }

public static void printSUB(int[][] A){
 StringBuffer elements = new StringBuffer();
  for(int row = 0; row < A.length; row++){
   for(int col = 0; col < A[row].length; col++){
    elements.append(A[row][col]);
    elements.append("     \t");
    }
   elements.append("\n");
   }
    JOptionPane.showMessageDialog(null, "-----Subtract Matrix-----\n"+elements.toString());
   }

public static void printCON(int[][] A){
 StringBuffer elements = new StringBuffer();
  for(int row = 0; row < A.length; row++){
   for(int col = 0; col < A[row].length; col++){
    elements.append(A[row][col]);
    elements.append("     \t");
    }
   elements.append("\n");
   }
    JOptionPane.showMessageDialog(null, "-----Constant times Matrix-----\n"+elements.toString());
   }

public static void printMUL(int[][] A){
 StringBuffer elements = new StringBuffer();
  for(int row = 0; row < A.length; row++){
   for(int col = 0; col < A[row].length; col++){
    elements.append(A[row][col]);
    elements.append("     \t");
    }
   elements.append("\n");
   }
    JOptionPane.showMessageDialog(null, "-----Multiplication Matrix-----\n"+elements.toString());
   }


public static void random(int[][] A){
  for(int row = 0; row < A.length; row++){
   for(int col = 0; col < A[row].length; col++){
    A[row][col] = (int)(Math.random() * 100);
       }
  }
}

//method sum
public static int[][] sum(int[][] A, int[][] B){
  int[][] sum = new int[A.length][A[0].length];
  for(int row = 0; row < A.length; row++){
   for(int col = 0; col < A[row].length; col++){
    sum[row][col] = A[row][col] + B[row][col];
    }
  }
  return sum;
}
 
//method sub
public static int[][] sub(int[][] A, int[][] B){
  int[][] sub = new int[A.length][A[0].length];
  for(int row = 0; row < A.length; row++){
   for(int col = 0; col < A[row].length; col++){
    sub[row][col] = A[row][col] - B[row][col];
   }
  }
  return sub;
}
 
//method diagSum
private static int diagSum(int[][] A){
  int plus = 0;
  for(int i = 0; i < A.length; i++ ){
   plus += A[i][i];
  }
     return plus;
}
 
//method diagProduct
private static int diagProduct( int[][] A ){
  int multiply = 1;
  for(int i = 0; i < A.length; i++ ){
  if(A[i][i] != 0 ){
   multiply *= A[i][i];
  }
  }
     return multiply;
}

 //method cayleyhamiltonTheorem
 private static String cayleyhamiltonTheorem(int[][] A){
  int c;
  c=A[0][0]+A[1][1];
  int d;
  d=A[0][0]*A[1][1]-A[0][1]*A[1][0];
  String ch = "A^2-"+c+"A+"+d+"E=O";
 return ch;
}

//method determinant
private static int determinant(int A[][], int n){
  int det = 0, sign = 1, p = 0, q = 0;
  if(n==1){
  det = A[0][0];
  }
  else{
  int b[][] = new int[n-1][n-1];
  for(int x=0; x<n; x++){
   p=0;q=0;
   for(int i=1; i<n; i++){
    for(int j=0; j<n; j++){
     if(j != x){
      b[p][q++] = A[i][j];
      if(q % (n-1) == 0){
       p++;
       q=0;
      }
     }
    }
   }
         det = det + A[0][x] * determinant(b, n-1) * sign;
      sign = -sign;
  }
  }
     return det;
}

//method con
public static int[][] con(int[][] A, int i){
  int[][] con = new int[A.length][A[0].length];
  for(int row = 0; row < A.length; row++){
  for(int col = 0; col < A[row].length; col++){
    con[row][col] = i*A[row][col];
  }
  }
  return con;
}
 
//method all
public static double all(int[][] A){
  double total = 0;
  for(int row = 0; row < A.length; row++){
     for(int col = 0; col < A[row].length; col++){
         total += A[row][col];
     }
  }
  return total;
}
 
//method noZeroCount
private static int noZeroCount(int[][] A){
  int count = 0;
  for(int i = 0; i < A.length; i++ ){
  for(int j = 0; j < A[i].length; j++ ){
   if(A[i][j] != 0 ) {
     count++;
    }
  }
  }
     return count;
}
  
//method multiply
public static int[][] multiply(int[][] A, int[][] B){
     int rowsInA = A.length;
     int columnsInA = A[0].length;
     int columnsInB = B[0].length;
     int[][] C = new int[rowsInA][columnsInB];
     for(int i = 0; i < rowsInA; i++) {
        for(int j = 0; j < columnsInB; j++) {
            for(int k = 0; k < columnsInA; k++) {
                    C[i][j] = C[i][j] + A[i][k] * B[k][j];
            }
        }
     }
     return C;
}
}