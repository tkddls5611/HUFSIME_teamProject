public class Calendar{
  public static void main(String[] args){
//m�� y �ֱ�
    int m = Integer.parseInt(args[0]);
    int y = Integer.parseInt(args[1]);
    
//�޷� �� �⵵
    System.out.print("     ");
    if(m == 1) System.out.print("January  ");
    else if(m == 2) System.out.print("February  ");
    else if(m == 3) System.out.print("March  ");
    else if(m == 4) System.out.print("April  ");
    else if(m == 5) System.out.print("May  ");
    else if(m == 6) System.out.print("June  ");
    else if(m == 7) System.out.print("July  ");
    else if(m == 8) System.out.print("August  ");
    else if(m == 9) System.out.print("September  ");
    else if(m == 10) System.out.print("October  ");
    else if(m == 11) System.out.print("November  ");
    else             System.out.print("December  ");
    System.out.println(y);
    System.out.println("S   M   Tu  W  Th   F   S");
    
//�� �ϼ� ���ϱ�
    int totaldays =0;
    if(m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12) totaldays = 31;
    if( m == 4 || m == 6 || m == 9 || m == 11)                               totaldays = 30;

//2���� ���� leapyear �Ǵ�
    boolean isLeapYear;
    isLeapYear = (y %4 ==0);
    isLeapYear = isLeapYear && (y%100 !=0);
    isLeapYear = isLeapYear || (y%400 ==0);

    if(m==2){
      if(isLeapYear)  totaldays = 29;
      else            totaldays = 28;
    }
//Dayofweek�� �Ἥ 1���� ���� �������� ����
    int d = 1;
    
    int y0 = y-(14-m)/12;
    int x = y0 + y0/4 -y0/100+y0/400;
    int m0 = m+12*((14-m)/12)-2;
    int d0 = (d+x+(31*m0)/12)%7;

//ù �� �� ���� �޷°� ���߱� ���� space
    for(int i=0;i<d0;i++){
      System.out.print("    ");
    }
    for(int i=1;i<=totaldays;i++){
      if(i<10){
        System.out.print(i+"   ");
      }else{
      System.out.print(i+"  ");
      }
      if((i+d0) %7==0)
      System.out.println();
    }
    System.out.println();
  }
}