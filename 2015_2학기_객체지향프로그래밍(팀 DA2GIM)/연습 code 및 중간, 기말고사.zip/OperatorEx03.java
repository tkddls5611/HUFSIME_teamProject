public class OperatorEx03 {
 public static void main(String[] args) {
  System.out.println("-----����������-----");
  boolean a,b,result;
  a = true;
  b = false;
  
  result = a && b;//true && false ->false
  System.out.println("a && b : " +result);
  
  result = a||b;//true || false ->true
  System.out.println("a || b : " +result);

  result = !a;//!a ->false
  System.out.println("!a : " +result);
 }
}
