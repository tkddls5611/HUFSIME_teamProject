public class LetterFrequency2{
    private String filename;
    private int[] frequency;

    public LetterFrequency(String filename) {
        this.filename = filename;
    }

    public void calculate_frequency() {
        /* read the file and calculate frequency */
    }
  
    public int[] get_frequency() {
        return frequency;
    }

    public void plot_histogram() {
        /* plot a graph of the frequency of letters */
    }

}
