import java.*;
public class LetterFrequency {
    private String filename;
    private int[] frequency;
    public LetterFrequency(String filename) {
        this.filename = filename;     
    }
    public void calculate_frequency() {
        /* read the file and calculate frequency */     
        
        frequency = new int[26];
        
        In file = new In(filename);
        
        while (file.hasNextChar()) {
            char letter = file.readChar();
            
            if (letter >= 'a' && letter <= 'z') {
                frequency[letter-'a']++;
            }
            
        }
        
    }   
    public int[] get_frequency() {
        return frequency;
    } 
    public void plot_histogram() {
        /* plot a graph of the frequency of letters */
        int max_fre = 0;
        
        for (int i=0; i<frequency.length; i++) {
            if (max_fre < frequency[i]) {
                max_fre = frequency[i];
            }
        }
        
        StdDraw.setXscale(0, 26);
        StdDraw.setYscale(0, max_fre);
        
        for (int i=0; i<frequency.length; i++) {
            StdDraw.filledRectangle(i+0.5, frequency[i]/2.0, 0.41, frequency[i]/2.0);
            
        }
    }
} 