public class RandomWalker 
{
    private int x;
    private int y;
    
    public void step() {
        double r = Math.random();
        
        if (r < 0.25) {
            x--;
        } else if (r < 0.5) {
            x++;
        } else if (r < 0.75) {
            y--;
        } else {
            y++;
        }
         
    }
    
    public double distance() {
        
        return Math.sqrt(x*x+y*y);
        
    }
    
    
    public static void main(String[] args) {
        int N = Integer.parseInt(args[0]);
        int M = Integer.parseInt(args[1]);
        
        double sum_statance = 0;
        
        for (int k=0; k<M; k++) {
            RandomWalker rw = new RandomWalker();
            
            for (int i=0; i<N; i++) {
                rw.step();
            }
            
            sum_statance += rw.distance();
        }
        
        System.out.println("Average distance is " + sum_statance/M);
        
    }
    
}