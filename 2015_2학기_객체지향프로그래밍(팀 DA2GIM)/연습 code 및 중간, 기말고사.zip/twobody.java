public class twobody {
  public void main(String[] args){
  Body.Body(3,2,5);
  }
}