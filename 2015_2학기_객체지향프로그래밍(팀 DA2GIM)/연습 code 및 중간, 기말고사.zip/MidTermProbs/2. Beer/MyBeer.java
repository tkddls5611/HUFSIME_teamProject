public class MyBeer{
    public static void main(String[] args){
        int N = Integer.parseInt(args[0]);
        if(N<21){ //enter N under 21
            int[] students = new int[N];
            for(int i=0;i<N;i++){ // give number to every students
                students[i] = i;
            }
            int[] beers = new int[N];
            for(int i=0;i<N;i++) // before emergency stdent i has beer i
                beers[i] = students[i];
            
            boolean check_mine = false; //check the beer is originally mine
            double count = 0;
            for(int i=0;i<=1000;i++){
              
                for(int k=0;k<N;k++){ // after return , beers are in random
                    int r = (int)(Math.random() * N);
                    int temp = beers[k];
                    beers[k] = beers[r]; 
                    beers[r] = temp;
                }
                
                check_mine = false; 
                for(int j=0;j<N;j++){
                    if(students[j] == beers[j]) // check student i has his or her original beer
                    check_mine = true;
                }
                if(check_mine == true){ // if student i gets his or her original beer
                    count++;
                }
            }
            double probability = count / 1000;
            StdOut.println("The probability that at least one student gets his or her original beer is "+probability+"."
                          +"So, simulating 1000 times, the chances that at least one student gets his or her original beer is "+(int)count);
        }else {
          //if enter N>21
            StdOut.println("Enter under 21. Please try again.");
        }
            
    }
}