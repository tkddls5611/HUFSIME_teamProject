public class Diamonds{
    public static void main(String[] args){
        int N = Integer.parseInt(args[0]); //how many diamonds do you want?
        double[][] square0 = {//foundation
            {0.5,0.0},
            {1.0,0.5},
            {0.5,1.0},
            {0.0,0.5}
        };
        StdDraw.setXscale(0.0 , 1.0);//set Xscale
        StdDraw.setYscale(0.0, 1.0);//set Yscale
        getSquare(square0); //draw first diamond
        
        double[][] squareN = new double[4][2];
        squareN = getMiddle(square0); //get points
        for(int i=0;i<N-1;i++){//draw diamonds
            if(i==0){
                getSquare(squareN);
            }else{
                squareN = getMiddle(squareN);
                getSquare(squareN);
            }
        }
    }
    public static void getSquare(double[][] matrix){ //print diamond
        StdDraw.line(matrix[0][0],matrix[0][1] , matrix[1][0], matrix[1][1]); 
        StdDraw.line(matrix[1][0],matrix[1][1] , matrix[2][0], matrix[2][1]);
        StdDraw.line(matrix[2][0],matrix[2][1] , matrix[3][0], matrix[3][1]);
        StdDraw.line(matrix[3][0],matrix[3][1] , matrix[0][0], matrix[0][1]);
        }
    public static double[][] getMiddle(double[][] square){ // get point
        double[][] matrix = new double[4][2];
        matrix[0][0] = (square[0][0]+square[1][0])/2;
        matrix[0][1] = (square[0][1]+square[1][1])/2;
        matrix[1][0] = (square[1][0]+square[2][0])/2;
        matrix[1][1] = (square[1][1]+square[2][1])/2;
        matrix[2][0] = (square[2][0]+square[3][0])/2;
        matrix[2][1] = (square[2][1]+square[3][1])/2;
        matrix[3][0] = (square[3][0]+square[0][0])/2;
        matrix[3][1] = (square[3][1]+square[0][1])/2;
        return matrix;
    }
}