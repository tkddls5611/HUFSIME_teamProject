public class GCD{
    public static void main(String[] args){
        int x = Integer.parseInt(args[0]);
        int y = Integer.parseInt(args[1]);
        if(x>y){
        System.out.println("The greatest common divisor for " + x+" and "+y+" is "+getGcd(x,y));
        }else{
        System.out.println("The greatest common divisor for " + x+" and "+y+" is "+getGcd(y,x));
        }
        
        }
    public static int getGcd(int x, int y){
        int gcd = 1;
        if(x%y ==0){
            return y;
        }else{
              for (int k = y / 2; k >= 1; k--) {
                  if (x % k == 0 && y % k == 0) {
                      gcd = k;
                      break;
                  }
              }
        }
    return gcd;
    }
    
}
    