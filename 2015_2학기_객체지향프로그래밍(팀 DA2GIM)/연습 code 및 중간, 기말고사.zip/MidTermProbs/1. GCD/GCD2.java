public class GCD2{
    public static void main(String[] args){
      
        while(!StdIn.isEmpty()){
            int x = StdIn.readInt(); 
            int y = StdIn.readInt();
            if(x>y){
                StdOut.println("The GCD of " + x+" and "+y+" is "+getGcd(x,y));
            }else{
                StdOut.println("The GCD of " + x+" and "+y+" is "+getGcd(y,x));
            }
        }
    }
    public static int getGcd(int x, int y){
        int gcd = 1;
        if(x%y ==0){
            return y;
        }else{
              for (int k = y / 2; k >= 1; k--) {
                  if (x % k == 0 && y % k == 0) {
                      gcd = k;
                      break;
                  }
              }
        }
    return gcd;
    }
  
}