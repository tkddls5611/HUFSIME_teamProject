package TP;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


public class woodfinal {
   
   public Multimap<String, ArrayList<Integer>> test = ArrayListMultimap.create();
   public Multimap<String, ArrayList<Integer>> finalopt1 = ArrayListMultimap.create();
   public Multimap<String, ArrayList<Integer>> finalopt2 = ArrayListMultimap.create();
   public Multimap<String, ArrayList<String>> finalopt3 = ArrayListMultimap.create();
   public Multimap<String, ArrayList<String>> finalopt4 = ArrayListMultimap.create();
   public Multimap<String, String> testtime = ArrayListMultimap.create();
   public ArrayList<String> tduration = new ArrayList<String>();

   protected int[] seq1;
   protected int[] seq2;
   protected int[][] warpingPath;
   protected long totalTime=0;
   protected String duration= new String();
   
   
   private int aw;
	public void setAw(int aw){
		this.aw=aw;
	}
	public int getAw(){
		return aw;
	}
	
	private int ad;
		public void setAd(int ad){
			this.ad=ad;
		}
	public int getAd(){
			return ad;
		}
		   
	private int mc;
	public void setMc(int mc){
				this.mc=mc;
			}
	public int getMc(){
		return mc;
	}
			   
	private int tarmc;
		public void setTarmc(int tarmc){
		this.tarmc=tarmc;
	}
	public int getTarmc(){
		return tarmc;
	}
				
	private double condition;
		public void setCondition(int condition){
		this.condition=condition;
	}
	public double getCondition(){
		return condition;
	}
	   

   protected ArrayList<String> data= new ArrayList<String>();
   protected ArrayList<String> dataTime= new ArrayList<String>();
   protected ArrayList<String> dataTimeMC= new ArrayList<String>();
   public ArrayList<String> schedule = new ArrayList<String>();
   
   public static void main(String[] args){
	   woodfinal h = new woodfinal();
   }// main
   
   public woodfinal()
   {
     build4();
   }
   
   private static Double distance (int ad, int aw, int mc, int rd, int rw, int mc1 ) {
         double dist=0;
         dist = Math.sqrt(Math.pow(ad-rd, 2)+Math.pow(aw-rw,2)+Math.pow(mc-mc1, 2));
         return dist;
      }
   
   private static ArrayList<Integer>distance(int tarmc ,ArrayList<Integer>mcs) {
      ArrayList<Integer> mcdist = new ArrayList<Integer>();
      ArrayList<Double>  mcdist1 = new ArrayList<Double>();
      ArrayList<Integer> mcdist2 = new ArrayList<Integer>();
      ArrayList<Double>  mcdist3= new ArrayList<Double>();
     
      if(Collections.min(mcs)>tarmc){
            mcdist.add(Collections.min(mcs));
            return mcdist;         
      }
      
      else if(Collections.max(mcs)<tarmc||!mcs.contains(tarmc)){
         for(int j=0; j<mcs.size(); j++){
           mcdist1.add(Math.sqrt(Math.pow(mcs.get(j)-tarmc, 2)));
           
         }
         
         for(int i=0; i<mcs.size(); i++){ 
            mcdist3.add((Collections.max(mcdist1)-mcdist1.get(i))/(Collections.max(mcdist1)-Collections.min(mcdist1)));//[0,1]
            if(mcdist3.get(i)>0.9){
               mcdist2.add(mcs.get(mcdist3.indexOf(mcdist3.get(i))));//[find mc more than 0.9
               }   
              if(i==mcs.size()-1){                  
                 
                  return mcdist2;
                  }   
         }
        }   
      return mcdist;
       }
  
   private static Double maxdistance(ArrayList<Double>dist){
         double maxdist=0;
         for(int i=0; i<dist.size(); i++)
         if(dist.get(i)>maxdist){
            maxdist=dist.get(i);
         }
         return maxdist;
      }

   private static Double mindistance(ArrayList<Double>dist){
         double mindist=999999;
         for(int i=0; i<dist.size(); i++)
         if(dist.get(i)<mindist){
            mindist=dist.get(i);
         }
         return mindist;
      }
      
   private static ArrayList<Double> normalization(ArrayList<Double>dist,double max, double min){
      ArrayList<Double> p= new ArrayList<Double>();
      for(int i=0; i<dist.size(); i++){
         p.add((dist.get(i)-min)/(max-min));
      }
      return p;
   }
   
   private static ArrayList<Double> filtermin(double condition,ArrayList<Double> normal){
      ArrayList<Double> filtered = new ArrayList<Double>();//= normal;       
      int index = normal.indexOf(0.0);
      //System.out.println("index : "+index);
      //conditon���� ���� normal �� array�� 
      for(int i=0; i<normal.size(); i++){
         //System.out.println("normal :"+normal.get(i));
         if(normal.get(i)<=condition){
            filtered.add(normal.get(i));   
           // System.out.println(" testing normalization condition : "+normal.get(i) + " -- " + condition);
         }
      }

      return filtered;
   }
   
   private ArrayList<Integer> getTimePos(ArrayList<Double> normal, ArrayList<Double> cond) {
      ArrayList<Integer> condindex = new ArrayList <Integer>();
         for(int i=0; i<cond.size(); i++){
            double a = cond.get(i);
            int b = normal.indexOf(a); 
            condindex.add(b);
            normal.remove(b);
            normal.add(b, 2.0);
            //indexof �� normal�� ó������ Ȯ�� �ϱ� ������ �ߺ� ���ڰ� ���� normal���� ã�� ���� �����  �ٸ������� ġȯ 
            }
   //   System.out.println(a + " -- " +cond.get(0)+ " -- "+cond.get(1)+ " == " +normal.get(0));
      
      return condindex;
   }
   
   public ArrayList<String> Schedule1(ArrayList<Integer> i1, ArrayList<Integer> i2, ArrayList<String> time) {
       data = new ArrayList<String>();
       dataTime= new ArrayList<String>();
       ArrayList<String> Schedule1=new ArrayList<String>();
        for(int i=0;i<i1.size();i++)
        {
         String   s = i1.get(i) + ";" +i2.get(i);
           if(!data.contains(s)){
              data.add(s);
              dataTime.add(s+","+time.get(i));
             // System.out.println(dataTime.size());
              Schedule1.add(i+";"+s+";"+time.get(i));
           }
           
        }
        return Schedule1;
     }
      private void Schedule(ArrayList<Integer> i1, ArrayList<Integer> i2, ArrayList<String> time) {
        data = new ArrayList<String>();
        dataTime= new ArrayList<String>();
         for(int i=0;i<i1.size();i++)
         {
          String   s = i1.get(i) + ";" +i2.get(i);
            if(!data.contains(s)){
               data.add(s);
               dataTime.add(s+","+time.get(i));
              // System.out.println(dataTime.size());
               //System.out.println(i+";"+s+";"+time.get(i));
            }
            
         }
         this.compute2();
      }

      public void compute2()
      {
         //put in the list to make the order

         ArrayList aSDB = new ArrayList();
         ArrayList aSWB = new ArrayList();
         //System.out.println(data.size());
         //set the set (distinct value)
               
         int index1=0, index2=0;
         for(int i=1;i<dataTime.size();i++)
         {
            
            String sb1="";
            String sb2="";
            boolean data1=false;
            boolean data2=false;
            
            String s1 = data.get(i).split(",")[0];
            String s2 = data.get(i).split(",")[1];

            String sch = "";
            String time=" ";
            if(i>0)
            {
               sch=index1+","+index2+","+data.get(i-1);
               sb1 = data.get(i-1).split(",")[0];
               sb2 = data.get(i-1).split(",")[1];
               String t1 = dataTime.get(i-1).split(",")[2];
               String t2 = dataTime.get(i).split(",")[2];
               //System.out.println(s1+";"+s2+";"+t1+";"+t2);
               time = computeTime(t1, t2);
               //System.out.println(sch+","+time);
               //totalTime = accum(time);
               schedule.add(sch+","+time);
            }else
            {sb1 = s1;
            sb2 = s2;
            }
            if((!aSDB.contains(s1)) || (!s1.equals(sb1))){
               aSDB.add(s1);
               index1++;
               data1=true;
            }
            if((!aSWB.contains(s2))|| (!s2.equals(sb2))){
               aSWB.add(s2);
               index2++;
               data2=true;
            }
            if(i==dataTime.size()-1)
            {
               sch=index1+","+index2+","+data.get(i);
               sb1 = data.get(i-1).split(",")[0];
               sb2 = data.get(i-1).split(",")[1];
               String t1 = dataTime.get(i).split(",")[2];
               String t2 = dataTime.get(i).split(",")[2];
               //System.out.println(s1+";"+s2+";"+t1+";"+t2);
               time = computeTime(t1, t2);
               //System.out.println(sch+","+time);
               //totalTime = accum(time);
               schedule.add(sch+","+time);
               t1 = dataTime.get(0).split(",")[2];
               t2 = dataTime.get(i).split(",")[2];
               duration = computeTime(t1,t2);
            }
         }
      }
      
      public String computeTime(String t1, String t2)
      {
         
         
         SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy HH:mm");  

         Date d1 = null;
         Date d2 = null;
         try {
             d1 = format.parse(t1);
             d2 = format.parse(t2);
         } 
         catch (ParseException e) {
             e.printStackTrace();
         }    

         // Get msec from each, and subtract.
         long diff = d2.getTime() - d1.getTime();
         //accum(diff);
         

         long diffSeconds = diff / 1000 % 60;
         long diffMinutes = diff / (60 * 1000) % 60;
         long diffHours = diff / (60 * 60 * 1000) % 24;
         long diffDays = diff / (24 * 60 * 60 * 1000);
         
         /*long diffSeconds = diff / 1000;         
         long diffMinutes = diff / (60 * 1000);         
         long diffHours = diff / (60 * 60 * 1000);  */      
         //System.out.println(t1 + "---- "+t2 + " == " +diffDays + " days " +diffHours + " hours");
         /*System.out.println("Time in seconds: " + diffSeconds + " seconds.");         
         System.out.println("Time in minutes: " + diffMinutes + " minutes.");         
         System.out.println("Time in hours: " + diffHours + " hours.");*/ 
         String time = diffDays+" days "+ diffHours + " hours ";
         return time;
      }
      
      
      public void print() {
         for(int i:seq1)
         {
            //System.out.println(i);
         }
         
         for(int i:seq2)
         {
            //System.out.println(i);
         }
      }

      public ArrayList<String> getSchedule()
      {
         return schedule;
      }
      
      public String getDuration()
      {
         return duration;
      }
   
   public Multimap<String, ArrayList<Integer>> build()
   {
	  // aw=30;ad=30;mc=30;tarmc=13;condition=0.0;
      
      ArrayList<String>needlist = new ArrayList<String>();
      ArrayList<String>needlist2 = new ArrayList<String>();
      ArrayList<String>needlist3 = new ArrayList<String>();
      ArrayList<Integer> mcsimlist = new ArrayList<Integer>(); //mc�� ������ ã������ ���� ����     
      try{
            
         //String FileName= (String) session.getAttribute("FileName");
         
         String manuf = "kd2016";
         Connection conn = null; 
         String url = "jdbc:mysql://203.253.70.34:3306/wood";        
         String id = "dmteam";                                                   
         String pw = "!dmteam";
         String name = null;
         Statement stmt3 = null;
         Statement stmtC = null;
         HashMap<String, Collection<ArrayList<Integer>>> needlistrow =new HashMap<String, Collection<ArrayList<Integer>>>();
         Multimap<Integer,String> testname = ArrayListMultimap.create(); 

         int ic=0;
         int i=0;
         ResultSet codeset = null;
         String query_code = null;
         String icode =null;
         
         try{
               
            Class.forName("com.mysql.jdbc.Driver");   
            conn=DriverManager.getConnection(url,id,pw);              
            
            stmt3 = conn.createStatement();
            stmtC = conn.createStatement();
            
            String query_str3 = "select distinct code from "+manuf+"";
            
            ResultSet rs3=stmt3.executeQuery(query_str3);
            String[] jcode =new String [8];
            
            while(rs3.next()){
                     
               icode = rs3.getString("code");
               jcode[ic] = rs3.getString("code");
               query_code = "select * from "+manuf+" where code = '"+icode+"'";
               codeset=stmtC.executeQuery(query_code);
               name = jcode[ic];
               testname.put(i, name);                    
//               String comtar = null;// tarmc�� �� �ϱ� ���� ������ ������ ���� 
                     
               while(codeset.next()){//KD1-*�� �����͸� �ҷ���
                  String kd = codeset.getString(1);
                  ArrayList<Integer> numblist = new ArrayList<Integer>();      
                  ArrayList<String>strlist = new ArrayList<String>();
                 
                  int numb0 = codeset.getInt("setDryTemp");
                  int numb1 = codeset.getInt("setWetTemp");
                  int numb2 = codeset.getInt("realDryTemp");
                  int numb3 = codeset.getInt("realWetTemp");
                  int numb4 = codeset.getInt("MC1");
                  String code=codeset.getString("Code");
                  String time=codeset.getString("Time");
                  
                  numblist.add(numb0);
                  numblist.add(numb1);
                  numblist.add(numb2);
                  numblist.add(numb3);
                  numblist.add(numb4);
                  strlist.add(time);
                  
                  test.put(kd, numblist);
                  testtime.put(kd, time);
                  
                  if(tarmc==numb4){
                     if(!needlist.contains(code)){
                        //if(!code.equals(comtar)){
                        needlist.add(code);
                        //comtar = code;
                     }
                  }
                  if(distance(ad,aw,mc,numb2,numb3,numb4)<10){
                     if(!needlist2.contains(code)){
                          //if(!code.equals(comtar)){
                          needlist2.add(code);
                          //comtar = code;
                       }
                  }
                 
                     
                //  System.out.println("numblist"+numblist.get(4));
                     mcsimlist.add(numblist.get(4));   
               }
               i++;  
            }
          //  System.out.println(needlist+""+needlist2);
            for(String z : needlist2){
              // System.out.println(needlist+""+needlist2);
               if(needlist.contains(z)){
                  needlist3.add(z);
               }
               
            }
            //System.out.println(needlist3);
            if(needlist.isEmpty()){
              
               System.out.println("we could not find the target mc in our database");
               HashSet hs = new HashSet(distance(tarmc,mcsimlist));
               System.out.println("nearest mc of your target mc is "+hs);
               
            }
            
            if(!needlist.isEmpty())
            {
              // System.out.println("���� ã�ƾ��� ����"+needlist3);
               HashMap<String,ArrayList<Double>> distlist = new HashMap<String,ArrayList<Double>>();
               Set<String> keyString = new HashSet<String>();
               keyString = test.keySet();
               
               for(String ss : keyString)
               {      
                  for(int p=0; p<needlist3.size(); p++){
                     if(ss.equals(needlist3.get(p))){
                        Collection<ArrayList<Integer>> code1 = test.get(ss);
                           Collection<String> colltimetemp = testtime.get(needlist3.get(p));
                           ArrayList<Double> temp = new ArrayList<Double>();
                           ArrayList<String> beftime = new ArrayList<String>();
                           ArrayList<Integer> finalsd = new ArrayList<Integer>();
                           ArrayList<Integer> finalsw = new ArrayList<Integer>();
                           ArrayList<Integer> finalmc = new ArrayList<Integer>();
                           ArrayList<Integer> finalrd = new ArrayList<Integer>();
                           ArrayList<Integer> finalrw = new ArrayList<Integer>();
                           
                           ArrayList<Integer> finalsd2 = new ArrayList<Integer>();
                           ArrayList<Integer> finalsw2 = new ArrayList<Integer>();
                           ArrayList<Integer> finalmc2 = new ArrayList<Integer>();
                           ArrayList<String> finaltime2 = new ArrayList<String>();
                           needlistrow.put(ss, code1);
                           for(ArrayList<Integer> k: code1){
                              ArrayList<ArrayList<Integer>> befnor = new ArrayList<ArrayList<Integer>>();
                              if(k.get(4)>=tarmc){//targetmc ���������� row�� befnor�� ����
                                 befnor.add(k);
                                 finalsd.add(k.get(0));
                                 finalsw.add(k.get(1));
                                 finalrd.add(k.get(2));
                                 finalrw.add(k.get(3));
                                 finalmc.add(k.get(4));
                              }
                              if(k.get(4)==tarmc){
                                 break;
                              }
                              int t=0;
                              for(String l : colltimetemp){//targetmc ���������� �ð��� beftime�� ���� 
                                 if(t<=befnor.size()){
                                    beftime.add(l);       
                                 }
                               
                                 if(t==befnor.size()){
                                    break;
                                 }
                              }
                           }
                           
                           for(int z=0; z<finalsd.size(); z++){
                              
                              double dis = distance(ad,aw,mc,finalrd.get(z),finalrw.get(z),finalmc.get(z));
                              
                              temp.add(dis);
                              
                           }
                           
                           distlist.put(ss,temp);//HashMap(String, arraylist<int>) distlist
                           double maxa =maxdistance(distlist.get(needlist3.get(p)));
                           double mina =mindistance(distlist.get(needlist3.get(p)));
                          
                           ArrayList<Double> normal = new ArrayList<Double>();
                           //normalization from the distance list
                           normal=normalization(distlist.get(needlist3.get(p)),maxa,mina);
                           ArrayList<Double> cond = new ArrayList<Double>();
                           cond=filtermin(condition,normal);//normal below condition
                           ArrayList<Integer> startTimePos = getTimePos(normal,cond);
                           
                           
                         //  System.out.println(needlist3.get(p));
                         //  System.out.println("startTimePos"+startTimePos);
                           
                                                      
                           ArrayList<String> startTimearr  = new ArrayList<String>();//startTimePos��°�� �ð� << startTimearr
                           try{
                              for(int z=0; z<startTimePos.size();z++){ 
                                 startTimearr.add(beftime.get(z));
                              }
                            //   System.out.println("startTimearr"+startTimearr);
                           
                          
                              for(Integer s : startTimePos){  
                                
                            	  	finalsd2 = new ArrayList<Integer>();
                                    finalsw2 = new ArrayList<Integer>();
                                    finalmc2 = new ArrayList<Integer>();
                                    finaltime2 = new ArrayList<String>();
                             //      System.out.println("startTImePos"+s);
                             //      System.out.println("finalsd"+finalsd.subList(s, finalsd.size()));
                             //     System.out.println("finalsw"+finalsw.subList(s, finalsw.size()));
                             //     System.out.println("finalmc"+finalmc.subList(s, finalmc.size()));
                             //     System.out.println("beftime"+beftime.subList(s, finalmc.size()));
                                  
                                    for(int w=0; w<finalsd.subList(s, finalsd.size()).size();s++){
                                     finalsd2.add(finalsd.subList(s, finalsd.size()).get(w));
                                     finalsw2.add(finalsw.subList(s, finalsw.size()).get(w));
                                     finalmc2.add(finalmc.subList(s, finalmc.size()).get(w));
                                     finaltime2.add(beftime.subList(s, finalmc.size()).get(w)); 
                                     
                                  } finalopt1.put(ss,finalsd2);
                                  	finalopt2.put(ss,finalsw2); 
                                  	finalopt3.put(ss, finaltime2);
                                    
                                  String endTime = finaltime2.get(finaltime2.size()-1);
                            //        System.out.println("endTime"+endTime);
                                  Schedule(finalsd2,finalsw2,finaltime2);
                                  
                                  
                                  //System.out.println("******************************************************");
                                 //duration�̶�� arraylist(string)�� ���� duration�� ����
                                  
                               }
                              
                              
                              System.out.println("-----------------------------------------------------");                   
                              
                              
                            	   
                              }
                       
                  catch(Exception e){
                      e.printStackTrace();
                     
                   }
                        }}}}}
           catch(Exception e){
            e.printStackTrace();
         }//System.out.println(finalopt1);
         
      }catch(Exception e){
         e.printStackTrace();
         
      }return finalopt1 ;}
   
   public Multimap<String, ArrayList<Integer>> build2()
   {
	  // aw=30;ad=30;mc=30;tarmc=13;condition=0.0;
      
      ArrayList<String>needlist = new ArrayList<String>();
      ArrayList<String>needlist2 = new ArrayList<String>();
      ArrayList<String>needlist3 = new ArrayList<String>();
      ArrayList<Integer> mcsimlist = new ArrayList<Integer>(); //mc�� ������ ã������ ���� ����     
      try{
            
         //String FileName= (String) session.getAttribute("FileName");
         
         String manuf = "kd2016";
         Connection conn = null; 
         String url = "jdbc:mysql://203.253.70.34:3306/wood";        
         String id = "dmteam";                                                   
         String pw = "!dmteam";
         String name = null;
         Statement stmt3 = null;
         Statement stmtC = null;
         HashMap<String, Collection<ArrayList<Integer>>> needlistrow =new HashMap<String, Collection<ArrayList<Integer>>>();
         Multimap<Integer,String> testname = ArrayListMultimap.create(); 

         int ic=0;
         int i=0;
         ResultSet codeset = null;
         String query_code = null;
         String icode =null;
         
         try{
               
            Class.forName("com.mysql.jdbc.Driver");   
            conn=DriverManager.getConnection(url,id,pw);              
            
            stmt3 = conn.createStatement();
            stmtC = conn.createStatement();
            
            String query_str3 = "select distinct code from "+manuf+"";
            
            ResultSet rs3=stmt3.executeQuery(query_str3);
            String[] jcode =new String [8];
            
            while(rs3.next()){
                     
               icode = rs3.getString("code");
               jcode[ic] = rs3.getString("code");
               query_code = "select * from "+manuf+" where code = '"+icode+"'";
               codeset=stmtC.executeQuery(query_code);
               name = jcode[ic];
               testname.put(i, name);                    
//               String comtar = null;// tarmc�� �� �ϱ� ���� ������ ������ ���� 
                     
               while(codeset.next()){//KD1-*�� �����͸� �ҷ���
                  String kd = codeset.getString(1);
                  ArrayList<Integer> numblist = new ArrayList<Integer>();      
                  ArrayList<String>strlist = new ArrayList<String>();
                 
                  int numb0 = codeset.getInt("setDryTemp");
                  int numb1 = codeset.getInt("setWetTemp");
                  int numb2 = codeset.getInt("realDryTemp");
                  int numb3 = codeset.getInt("realWetTemp");
                  int numb4 = codeset.getInt("MC1");
                  String code=codeset.getString("Code");
                  String time=codeset.getString("Time");
                  
                  numblist.add(numb0);
                  numblist.add(numb1);
                  numblist.add(numb2);
                  numblist.add(numb3);
                  numblist.add(numb4);
                  strlist.add(time);
                  
                  test.put(kd, numblist);
                  testtime.put(kd, time);
                  
                  if(tarmc==numb4){
                     if(!needlist.contains(code)){
                        //if(!code.equals(comtar)){
                        needlist.add(code);
                        //comtar = code;
                     }
                  }
                  if(distance(ad,aw,mc,numb2,numb3,numb4)<10){
                     if(!needlist2.contains(code)){
                          //if(!code.equals(comtar)){
                          needlist2.add(code);
                          //comtar = code;
                       }
                  }
                 
                     
                //  System.out.println("numblist"+numblist.get(4));
                     mcsimlist.add(numblist.get(4));   
               }
               i++;  
            }
          //  System.out.println(needlist+""+needlist2);
            for(String z : needlist2){
              // System.out.println(needlist+""+needlist2);
               if(needlist.contains(z)){
                  needlist3.add(z);
               }
               
            }
            System.out.println(needlist3);
            if(needlist.isEmpty()){
              
               System.out.println("we could not find the target mc in our database");
               HashSet hs = new HashSet(distance(tarmc,mcsimlist));
               System.out.println("nearest mc of your target mc is "+hs);
               
            }
            
            if(!needlist.isEmpty())
            {
              // System.out.println("���� ã�ƾ��� ����"+needlist3);
               HashMap<String,ArrayList<Double>> distlist = new HashMap<String,ArrayList<Double>>();
               Set<String> keyString = new HashSet<String>();
               keyString = test.keySet();
               
               for(String ss : keyString)
               {      
                  for(int p=0; p<needlist3.size(); p++){
                     if(ss.equals(needlist3.get(p))){
                        Collection<ArrayList<Integer>> code1 = test.get(ss);
                           Collection<String> colltimetemp = testtime.get(needlist3.get(p));
                           ArrayList<Double> temp = new ArrayList<Double>();
                           ArrayList<String> beftime = new ArrayList<String>();
                           ArrayList<Integer> finalsd = new ArrayList<Integer>();
                           ArrayList<Integer> finalsw = new ArrayList<Integer>();
                           ArrayList<Integer> finalmc = new ArrayList<Integer>();
                           ArrayList<Integer> finalrd = new ArrayList<Integer>();
                           ArrayList<Integer> finalrw = new ArrayList<Integer>();
                           
                           ArrayList<Integer> finalsd2 = new ArrayList<Integer>();
                           ArrayList<Integer> finalsw2 = new ArrayList<Integer>();
                           ArrayList<Integer> finalmc2 = new ArrayList<Integer>();
                           ArrayList<String> finaltime2 = new ArrayList<String>();
                           needlistrow.put(ss, code1);
                           for(ArrayList<Integer> k: code1){
                              ArrayList<ArrayList<Integer>> befnor = new ArrayList<ArrayList<Integer>>();
                              if(k.get(4)>=tarmc){//targetmc ���������� row�� befnor�� ����
                                 befnor.add(k);
                                 finalsd.add(k.get(0));
                                 finalsw.add(k.get(1));
                                 finalrd.add(k.get(2));
                                 finalrw.add(k.get(3));
                                 finalmc.add(k.get(4));
                              }
                              if(k.get(4)==tarmc){
                                 break;
                              }
                              int t=0;
                              for(String l : colltimetemp){//targetmc ���������� �ð��� beftime�� ���� 
                                 if(t<=befnor.size()){
                                    beftime.add(l);       
                                 }
                               
                                 if(t==befnor.size()){
                                    break;
                                 }
                              }
                           }
                           
                           for(int z=0; z<finalsd.size(); z++){
                              
                              double dis = distance(ad,aw,mc,finalrd.get(z),finalrw.get(z),finalmc.get(z));
                              
                              temp.add(dis);
                              
                           }
                           
                           distlist.put(ss,temp);//HashMap(String, arraylist<int>) distlist
                           double maxa =maxdistance(distlist.get(needlist3.get(p)));
                           double mina =mindistance(distlist.get(needlist3.get(p)));
                          
                           ArrayList<Double> normal = new ArrayList<Double>();
                           //normalization from the distance list
                           normal=normalization(distlist.get(needlist3.get(p)),maxa,mina);
                           ArrayList<Double> cond = new ArrayList<Double>();
                           cond=filtermin(condition,normal);//normal below condition
                           ArrayList<Integer> startTimePos = getTimePos(normal,cond);
                           
                           
                         //  System.out.println(needlist3.get(p));
                         //  System.out.println("startTimePos"+startTimePos);
                           
                                                      
                           ArrayList<String> startTimearr  = new ArrayList<String>();//startTimePos��°�� �ð� << startTimearr
                           try{
                              for(int z=0; z<startTimePos.size();z++){ 
                                 startTimearr.add(beftime.get(z));
                              }
                            //   System.out.println("startTimearr"+startTimearr);
                           
                          
                              for(Integer s : startTimePos){  
                                
                            	  	finalsd2 = new ArrayList<Integer>();
                                    finalsw2 = new ArrayList<Integer>();
                                    finalmc2 = new ArrayList<Integer>();
                                    finaltime2 = new ArrayList<String>();
                             //      System.out.println("startTImePos"+s);
                             //      System.out.println("finalsd"+finalsd.subList(s, finalsd.size()));
                             //     System.out.println("finalsw"+finalsw.subList(s, finalsw.size()));
                             //     System.out.println("finalmc"+finalmc.subList(s, finalmc.size()));
                             //     System.out.println("beftime"+beftime.subList(s, finalmc.size()));
                                  
                                    for(int w=0; w<finalsd.subList(s, finalsd.size()).size();s++){
                                     finalsd2.add(finalsd.subList(s, finalsd.size()).get(w));
                                     finalsw2.add(finalsw.subList(s, finalsw.size()).get(w));
                                     finalmc2.add(finalmc.subList(s, finalmc.size()).get(w));
                                     finaltime2.add(beftime.subList(s, finalmc.size()).get(w)); 
                                     
                                  } finalopt1.put(ss,finalsd2);
                                  	finalopt2.put(ss,finalsw2); 
                                  	finalopt3.put(ss, finaltime2);
                                    
                                  String endTime = finaltime2.get(finaltime2.size()-1);
                            //        System.out.println("endTime"+endTime);
                                  Schedule(finalsd2,finalsw2,finaltime2);
                                  
                                  
                                  //System.out.println("******************************************************");
                                 //duration�̶�� arraylist(string)�� ���� duration�� ����
                                  
                               }
                              
                              
                              System.out.println("-----------------------------------------------------");                   
                              
                              
                            	   
                              }
                       
                  catch(Exception e){
                      e.printStackTrace();
                     
                   }
                        }}}}}
           catch(Exception e){
            e.printStackTrace();
         }//System.out.println(finalopt1);
         
      }catch(Exception e){
         e.printStackTrace();
         
      }return finalopt2 ;}
   public Multimap<String, ArrayList<String>> build3()
   {
	  // aw=30;ad=30;mc=30;tarmc=13;condition=0.0;
      
      ArrayList<String>needlist = new ArrayList<String>();
      ArrayList<String>needlist2 = new ArrayList<String>();
      ArrayList<String>needlist3 = new ArrayList<String>();
      ArrayList<Integer> mcsimlist = new ArrayList<Integer>(); //mc�� ������ ã������ ���� ����     
      try{
            
         //String FileName= (String) session.getAttribute("FileName");
         
         String manuf = "kd2016";
         Connection conn = null; 
         String url = "jdbc:mysql://203.253.70.34:3306/wood";        
         String id = "dmteam";                                                   
         String pw = "!dmteam";
         String name = null;
         Statement stmt3 = null;
         Statement stmtC = null;
         HashMap<String, Collection<ArrayList<Integer>>> needlistrow =new HashMap<String, Collection<ArrayList<Integer>>>();
         Multimap<Integer,String> testname = ArrayListMultimap.create(); 

         int ic=0;
         int i=0;
         ResultSet codeset = null;
         String query_code = null;
         String icode =null;
         
         try{
               
            Class.forName("com.mysql.jdbc.Driver");   
            conn=DriverManager.getConnection(url,id,pw);              
            
            stmt3 = conn.createStatement();
            stmtC = conn.createStatement();
            
            String query_str3 = "select distinct code from "+manuf+"";
            
            ResultSet rs3=stmt3.executeQuery(query_str3);
            String[] jcode =new String [8];
            
            while(rs3.next()){
                     
               icode = rs3.getString("code");
               jcode[ic] = rs3.getString("code");
               query_code = "select * from "+manuf+" where code = '"+icode+"'";
               codeset=stmtC.executeQuery(query_code);
               name = jcode[ic];
               testname.put(i, name);                    
//               String comtar = null;// tarmc�� �� �ϱ� ���� ������ ������ ���� 
                     
               while(codeset.next()){//KD1-*�� �����͸� �ҷ���
                  String kd = codeset.getString(1);
                  ArrayList<Integer> numblist = new ArrayList<Integer>();      
                  ArrayList<String>strlist = new ArrayList<String>();
                 
                  int numb0 = codeset.getInt("setDryTemp");
                  int numb1 = codeset.getInt("setWetTemp");
                  int numb2 = codeset.getInt("realDryTemp");
                  int numb3 = codeset.getInt("realWetTemp");
                  int numb4 = codeset.getInt("MC1");
                  String code=codeset.getString("Code");
                  String time=codeset.getString("Time");
                  
                  numblist.add(numb0);
                  numblist.add(numb1);
                  numblist.add(numb2);
                  numblist.add(numb3);
                  numblist.add(numb4);
                  strlist.add(time);
                  
                  test.put(kd, numblist);
                  testtime.put(kd, time);
                  
                  if(tarmc==numb4){
                     if(!needlist.contains(code)){
                        //if(!code.equals(comtar)){
                        needlist.add(code);
                        //comtar = code;
                     }
                  }
                  if(distance(ad,aw,mc,numb2,numb3,numb4)<10){
                     if(!needlist2.contains(code)){
                          //if(!code.equals(comtar)){
                          needlist2.add(code);
                          //comtar = code;
                       }
                  }
                 
                     
                //  System.out.println("numblist"+numblist.get(4));
                     mcsimlist.add(numblist.get(4));   
               }
               i++;  
            }
          //  System.out.println(needlist+""+needlist2);
            for(String z : needlist2){
              // System.out.println(needlist+""+needlist2);
               if(needlist.contains(z)){
                  needlist3.add(z);
               }
               
            }
            System.out.println(needlist3);
            if(needlist.isEmpty()){
              
               System.out.println("we could not find the target mc in our database");
               HashSet hs = new HashSet(distance(tarmc,mcsimlist));
               System.out.println("nearest mc of your target mc is "+hs);
               
            }
            
            if(!needlist.isEmpty())
            {
              // System.out.println("���� ã�ƾ��� ����"+needlist3);
               HashMap<String,ArrayList<Double>> distlist = new HashMap<String,ArrayList<Double>>();
               Set<String> keyString = new HashSet<String>();
               keyString = test.keySet();
               
               for(String ss : keyString)
               {      
                  for(int p=0; p<needlist3.size(); p++){
                     if(ss.equals(needlist3.get(p))){
                        Collection<ArrayList<Integer>> code1 = test.get(ss);
                           Collection<String> colltimetemp = testtime.get(needlist3.get(p));
                           ArrayList<Double> temp = new ArrayList<Double>();
                           ArrayList<String> beftime = new ArrayList<String>();
                           ArrayList<Integer> finalsd = new ArrayList<Integer>();
                           ArrayList<Integer> finalsw = new ArrayList<Integer>();
                           ArrayList<Integer> finalmc = new ArrayList<Integer>();
                           ArrayList<Integer> finalrd = new ArrayList<Integer>();
                           ArrayList<Integer> finalrw = new ArrayList<Integer>();
                           
                           ArrayList<Integer> finalsd2 = new ArrayList<Integer>();
                           ArrayList<Integer> finalsw2 = new ArrayList<Integer>();
                           ArrayList<Integer> finalmc2 = new ArrayList<Integer>();
                           ArrayList<String> finaltime2 = new ArrayList<String>();
                           needlistrow.put(ss, code1);
                           for(ArrayList<Integer> k: code1){
                              ArrayList<ArrayList<Integer>> befnor = new ArrayList<ArrayList<Integer>>();
                              if(k.get(4)>=tarmc){//targetmc ���������� row�� befnor�� ����
                                 befnor.add(k);
                                 finalsd.add(k.get(0));
                                 finalsw.add(k.get(1));
                                 finalrd.add(k.get(2));
                                 finalrw.add(k.get(3));
                                 finalmc.add(k.get(4));
                              }
                              if(k.get(4)==tarmc){
                                 break;
                              }
                              int t=0;
                              for(String l : colltimetemp){//targetmc ���������� �ð��� beftime�� ���� 
                                 if(t<=befnor.size()){
                                    beftime.add(l);       
                                 }
                               
                                 if(t==befnor.size()){
                                    break;
                                 }
                              }
                           }
                           
                           for(int z=0; z<finalsd.size(); z++){
                              
                              double dis = distance(ad,aw,mc,finalrd.get(z),finalrw.get(z),finalmc.get(z));
                              
                              temp.add(dis);
                              
                           }
                           
                           distlist.put(ss,temp);//HashMap(String, arraylist<int>) distlist
                           double maxa =maxdistance(distlist.get(needlist3.get(p)));
                           double mina =mindistance(distlist.get(needlist3.get(p)));
                          
                           ArrayList<Double> normal = new ArrayList<Double>();
                           //normalization from the distance list
                           normal=normalization(distlist.get(needlist3.get(p)),maxa,mina);
                           ArrayList<Double> cond = new ArrayList<Double>();
                           cond=filtermin(condition,normal);//normal below condition
                           ArrayList<Integer> startTimePos = getTimePos(normal,cond);
                           
                           
                         //  System.out.println(needlist3.get(p));
                         //  System.out.println("startTimePos"+startTimePos);
                           
                                                      
                           ArrayList<String> startTimearr  = new ArrayList<String>();//startTimePos��°�� �ð� << startTimearr
                           try{
                              for(int z=0; z<startTimePos.size();z++){ 
                                 startTimearr.add(beftime.get(z));
                              }
                            //   System.out.println("startTimearr"+startTimearr);
                           
                          
                              for(Integer s : startTimePos){  
                                
                            	  	finalsd2 = new ArrayList<Integer>();
                                    finalsw2 = new ArrayList<Integer>();
                                    finalmc2 = new ArrayList<Integer>();
                                    finaltime2 = new ArrayList<String>();
                             //      System.out.println("startTImePos"+s);
                             //      System.out.println("finalsd"+finalsd.subList(s, finalsd.size()));
                             //     System.out.println("finalsw"+finalsw.subList(s, finalsw.size()));
                             //     System.out.println("finalmc"+finalmc.subList(s, finalmc.size()));
                             //     System.out.println("beftime"+beftime.subList(s, finalmc.size()));
                                  
                                    for(int w=0; w<finalsd.subList(s, finalsd.size()).size();s++){
                                     finalsd2.add(finalsd.subList(s, finalsd.size()).get(w));
                                     finalsw2.add(finalsw.subList(s, finalsw.size()).get(w));
                                     finalmc2.add(finalmc.subList(s, finalmc.size()).get(w));
                                     finaltime2.add(beftime.subList(s, finalmc.size()).get(w)); 
                                     
                                  } finalopt1.put(ss,finalsd2);
                                  	finalopt2.put(ss,finalsw2); 
                                  	finalopt3.put(ss, finaltime2);
                                    
                                  String endTime = finaltime2.get(finaltime2.size()-1);
                            //        System.out.println("endTime"+endTime);
                                  Schedule(finalsd2,finalsw2,finaltime2);
                                  
                                  
                                // System.out.println("******************************************************");
                                 //duration�̶�� arraylist(string)�� ���� duration�� ����
                                  
                               }
                              
                              
                              System.out.println("-----------------------------------------------------");                   
                              
                              
                            	   
                              }
                       
                  catch(Exception e){
                      e.printStackTrace();
                     
                   }
                        }}}}}
           catch(Exception e){
            e.printStackTrace();
         }//System.out.println(finalopt1);
         
      }catch(Exception e){
         e.printStackTrace();
         
      }return finalopt3;}
  
   
   public Multimap<String, ArrayList<String>> build4()
   {
      
      ArrayList<String>needlist = new ArrayList<String>();
      ArrayList<String>needlist2 = new ArrayList<String>();
      ArrayList<String>needlist3 = new ArrayList<String>();
      
      ArrayList<Integer> mcsimlist = new ArrayList<Integer>(); //mc�� ������ ã������ ���� ����     
      try{
            
         //String FileName= (String) session.getAttribute("FileName");
         
         String manuf = "kd2016";
         Connection conn = null; 
         String url = "jdbc:mysql://203.253.70.34:3306/wood";        
         String id = "dmteam";                                                   
         String pw = "!dmteam";
         String name = null;
         Statement stmt3 = null;
         Statement stmtC = null;
         HashMap<String, Collection<ArrayList<Integer>>> needlistrow =new HashMap<String, Collection<ArrayList<Integer>>>();
         Multimap<Integer,String> testname = ArrayListMultimap.create(); 

         int ic=0;
         int i=0;
         ResultSet codeset = null;
         String query_code = null;
         String icode =null;
         
         try{
               
            Class.forName("com.mysql.jdbc.Driver");   
            conn=DriverManager.getConnection(url,id,pw);              
            
            stmt3 = conn.createStatement();
            stmtC = conn.createStatement();
            
            String query_str3 = "select distinct code from "+manuf+"";
            
            ResultSet rs3=stmt3.executeQuery(query_str3);
            String[] jcode =new String [8];
            
            while(rs3.next()){
                     
               icode = rs3.getString("code");
               jcode[ic] = rs3.getString("code");
               query_code = "select * from "+manuf+" where code = '"+icode+"'";
               codeset=stmtC.executeQuery(query_code);
               name = jcode[ic];
               testname.put(i, name);                    
//               String comtar = null;// tarmc�� �� �ϱ� ���� ������ ������ ���� 
                     
               while(codeset.next()){//KD1-*�� �����͸� �ҷ���
                  String kd = codeset.getString(1);
                  ArrayList<Integer> numblist = new ArrayList<Integer>();      
                  ArrayList<String>strlist = new ArrayList<String>();
                 
                  int numb0 = codeset.getInt("setDryTemp");
                  int numb1 = codeset.getInt("setWetTemp");
                  int numb2 = codeset.getInt("realDryTemp");
                  int numb3 = codeset.getInt("realWetTemp");
                  int numb4 = codeset.getInt("MC1");
                  String code=codeset.getString("Code");
                  String time=codeset.getString("Time");
                  
                  numblist.add(numb0);
                  numblist.add(numb1);
                  numblist.add(numb2);
                  numblist.add(numb3);
                  numblist.add(numb4);
                  strlist.add(time);
                  
                  test.put(kd, numblist);
                  testtime.put(kd, time);
                  
                  if(tarmc==numb4){
                     if(!needlist.contains(code)){
                        //if(!code.equals(comtar)){
                        needlist.add(code);
                        //comtar = code;
                     }
                  }
                  if(distance(ad,aw,mc,numb2,numb3,numb4)<5){
                     if(!needlist2.contains(code)){
                          //if(!code.equals(comtar)){
                          needlist2.add(code);
                          //comtar = code;
                       }
                  }
                 
                     
                //  System.out.println("numblist"+numblist.get(4));
                     mcsimlist.add(numblist.get(4));   
               }
               i++;  
            }
          //  System.out.println(needlist+""+needlist2);
            for(String z : needlist2){
              // System.out.println(needlist+""+needlist2);
               if(needlist.contains(z)){
                  needlist3.add(z);
               }
               
            } 
            //System.out.println(needlist3);
            if(needlist.isEmpty()){
              
               System.out.println("we could not find the target mc in our database");
               HashSet hs = new HashSet(distance(tarmc,mcsimlist));
               System.out.println("nearest mc of your target mc is "+hs);
               
            }
            
            if(!needlist.isEmpty())
            {
               //System.out.println("���� ã�ƾ��� ����"+needlist3);
               HashMap<String,ArrayList<Double>> distlist = new HashMap<String,ArrayList<Double>>();
               Set<String> keyString = new HashSet<String>();
               keyString = test.keySet();
               
               for(String ss : keyString)
               {      
                  for(int p=0; p<needlist3.size(); p++){
                     if(ss.equals(needlist3.get(p))){
                        Collection<ArrayList<Integer>> code1 = test.get(ss);
                           Collection<String> colltimetemp = testtime.get(needlist3.get(p));
                           ArrayList<Double> temp = new ArrayList<Double>();
                           ArrayList<String> beftime = new ArrayList<String>();
                           ArrayList<Integer> finalsd = new ArrayList<Integer>();
                           ArrayList<Integer> finalsw = new ArrayList<Integer>();
                           ArrayList<Integer> finalmc = new ArrayList<Integer>();
                           ArrayList<Integer> finalrd = new ArrayList<Integer>();
                           ArrayList<Integer> finalrw = new ArrayList<Integer>();
                           
                           ArrayList<Integer> finalsd2 = new ArrayList<Integer>();
                           ArrayList<Integer> finalsw2 = new ArrayList<Integer>();
                           ArrayList<Integer> finalmc2 = new ArrayList<Integer>();
                           ArrayList<String> finaltime2 = new ArrayList<String>();
                           double maxa =0;
                           double mina =0;
                           needlistrow.put(ss, code1);
                           for(ArrayList<Integer> k: code1){
                              ArrayList<ArrayList<Integer>> befnor = new ArrayList<ArrayList<Integer>>();
                              if(k.get(4)>=tarmc){//targetmc ���������� row�� befnor�� ����
                                 befnor.add(k);
                                 finalsd.add(k.get(0));
                                 finalsw.add(k.get(1));
                                 finalrd.add(k.get(2));
                                 finalrw.add(k.get(3));
                                 finalmc.add(k.get(4));
                              }
                              if(k.get(4)==tarmc){
                                 break;
                              }
                              int t=0;
                              for(String l : colltimetemp){//targetmc ���������� �ð��� beftime�� ���� 
                                 if(t<=befnor.size()){
                                    beftime.add(l);       
                                 }
                               
                                 if(t==befnor.size()){
                                    break;
                                 }
                              }
                           }
                           
                           for(int z=0; z<finalsd.size(); z++){
                              
                              double dis = distance(ad,aw,mc,finalrd.get(z),finalrw.get(z),finalmc.get(z));
                              
                              temp.add(dis);
                              
                           }
                           //System.out.println(temp);
                          if(temp.size()>1){
                           distlist.put(ss,temp);//HashMap(String, arraylist<int>) distlist
                         
                           maxa =maxdistance(distlist.get(needlist3.get(p)));
                           mina =mindistance(distlist.get(needlist3.get(p)));
                           //System.out.println(mina+" "+ maxa);
                           
                           ArrayList<Double> normal = new ArrayList<Double>();
                           //normalization from the distance list
                           normal=normalization(distlist.get(needlist3.get(p)),maxa,mina);
                           ArrayList<Double> cond = new ArrayList<Double>();
                           cond=filtermin(condition,normal);//normal below condition
                           //System.out.println(normal+" "+ cond);
                          
                           ArrayList<Integer> startTimePos = getTimePos(normal,cond);
                           
                           
                           //System.out.println(needlist3.get(p));
                          
                           //System.out.println("startTimePos"+startTimePos);
                          
                                                 
                           ArrayList<String> startTimearr  = new ArrayList<String>();//startTimePos��°�� �ð� << startTimearr
                           try{
                              for(int z=0; z<startTimePos.size();z++){ 
                                 startTimearr.add(beftime.get(z));
                              }
                              //System.out.println("startTimearr"+startTimearr);
                           
                           
                              for(Integer s : startTimePos){  
                                if(s.equals(startTimePos.get(startTimePos.size()-1))&&!startTimePos.isEmpty()){
                            	  	finalsd2 = new ArrayList<Integer>();
                                    finalsw2 = new ArrayList<Integer>();
                                    finalmc2 = new ArrayList<Integer>();
                                    finaltime2 = new ArrayList<String>();
                                  //System.out.println("startTImePos"+s);
                                  //System.out.println("finalsd"+finalsd.subList(s, finalsd.size()));
                                  //System.out.println("finalsw"+finalsw.subList(s, finalsw.size()));
                                  //System.out.println("finalmc"+finalmc.subList(s, finalmc.size()));
                                  //System.out.println("beftime"+beftime.subList(s, finalmc.size()));
                                  
                                    for(int w=0; w<finalsd.subList(s, finalsd.size()).size();s++){
                                     finalsd2.add(finalsd.subList(s, finalsd.size()).get(w));
                                     finalsw2.add(finalsw.subList(s, finalsw.size()).get(w));
                                     finalmc2.add(finalmc.subList(s, finalmc.size()).get(w));
                                     finaltime2.add(beftime.subList(s, finalmc.size()).get(w)); 
                                     
                                  } finalopt1.put(ss,finalsd2);
                                  	finalopt2.put(ss,finalsw2); 
                                  	finalopt3.put(ss, finaltime2);
                                  	finalopt4.put(ss, Schedule1(finalsd2,finalsw2,finaltime2));
                                  String endTime = finaltime2.get(finaltime2.size()-1);
                            //        System.out.println("endTime"+endTime);
                                  
                                  
                                  
                                  //System.out.println("******************************************************");
                                 //duration�̶�� arraylist(string)�� ���� duration�� ����
                                  
                               }
                              
                              }
                              //System.out.println("-----------------------------------------------------");                   
                              
                              
                            	   
                              }
                           
                  catch(Exception e){
                      e.printStackTrace();
                     
                   }}
                        }}}}}
           catch(Exception e){
            e.printStackTrace();
         }//System.out.println(finalopt1);
         
      }catch(Exception e){
         e.printStackTrace();
         
      }return finalopt4; }
   
   
   
}